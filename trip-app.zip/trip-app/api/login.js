import service from './mockAjax.js'
//添加标签
export function login(data) {
    return service({
        url: '/login',
        data: data,
        method: 'post'
    })
}
<template>
  <view>
    <view class="item-catelist">
      <view class="catelist2-list" v-for="(item2,i2) in list" :key="i2">
        <view class="list2-item">
            <!-- 景点图片 -->
              <image class="item-imgs" mode="" :src="item2.pictures[0]" @click="goDetail(item2)"></image>
              <view class="title">
                {{item2.title}}
              </view>
            <!-- 该文章展示内容 -->
            <view class="item-bottom">
              <!-- 作者基本信息 -->
              <view class="bottom-left">
                <image class="user_ava" :src="item2.userVo.headPortait" mode=""></image>
                <view class="user_name">{{item2.userVo.username}}</view>
              </view>
              <view class="bottom-right">
                <!-- <image src="../../static/点赞.png" mode=""></image> -->
                <image v-if="item2.isCollection==1" src="../../static/收藏 (2).png" mode=""></image>
                <image v-else src="../../static/收藏.png" mode=""></image>
              </view>
            </view>
          
        </view>
      </view>
    </view>
  </view>
</template>

<script>
  export default {
    name:"article-list",
    data() {
      return {
        
      };
    },
    props:['list'],
    methods:{
     async goDetail(item2){
        console.log(item2);
        let id= wx.getStorageSync('id')
        //获取浏览的id文章
        const {data:res}=await uni.$http.post('/articles/browse/'+id)
        // if(res.code!=200) return uni.$showMsg('')
        // console.log(item2);
        // if(item2.userVo.id==id){
          uni.navigateTo({
            url:'/subpkg/my-article-detail/my-article-detail?item='+encodeURIComponent(JSON.stringify(item2))

          })
        // }
        // else{
        //   uni.navigateTo({
        //     url:'/subpkg/article_detail/article_detail?id='+item2.id
        //   })
        // }
      }
    }
  }
</script>

<style lang="scss">
.item-catelist{
  display: flex;
  flex-wrap: wrap;
  flex: 0 0 47%;
  // justify-content: center;
  .catelist2-list{
    width: 47%;
    // height: 520rpx;
    flex-shrink:0;
    margin: 10rpx 8rpx;
    .list2-item{
      width: 100%;
      height: 100%;
      border-radius: 20rpx;
      background-color: #fff;
        .item-imgs{
          border-radius: 20rpx;
            width: 100%;
            height: 400rpx;
        }
    }
    .title{
      margin-left: 10rpx;
      font-size: 34rpx;
      color: #707e60;
     word-break:keep-all;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis; 
    }
    .item-bottom{
      display: flex;
      justify-content: space-between;
      image{
        width: 50rpx;
        height: 50rpx;
      }
      .bottom-left{
        display: flex;
        align-items: center;
       .user_ava{
         border-radius: 50%;
         margin-bottom: 5rpx;
         margin-left: 5rpx;
         margin-right: 15rpx;
       } 
       .user_name{
         font-size: 20rpx
       }
      }
    }
  }
}
</style>
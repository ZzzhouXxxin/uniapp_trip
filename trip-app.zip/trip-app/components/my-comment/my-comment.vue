<template>
  <view class="my-comment">
    <view class="comment-box">
        <view class="author">
         <view class="author-left" @click="goUserHome(article.userVo.id)">
           <image class="img" :src="article.userVo.headPortait"></image>
         <!--  <text>{{article.userVo.username}}</text> -->
         </view>
         <view class="author-right">
           <input class="input" type="text" @input="bindInputMsg" placeholder="说点什么吧!">
           <view class="input-item" @click="addleave(article.id)">评论</view>
         </view>
      </view>
    </view>
    <view class="comment-list" v-for="(item,i) in list1" :key="i">
      <view class="comment-item">
     <view class="item-left">
       <image class="ava-com" :src="item.author.headPortait" mode="" @click="goUserHome(item.author.id)"></image>
       <view class="item-connent">
         <view class="connent-top">
           {{item.author.username}}
         </view>
           <text class="content">{{item.content}}</text>
           <text class="time">{{item.createDate}}</text>
       </view>
     </view>
         <view class="caozuo">
           <text  @click="replay(item)" class="replay">回复</text>
           <text @click="jubao(item.id)" class="jubao">举报</text>
         </view>
        </view>
  <!-- 点击评论出现文本框 -->
        <view v-if="isShowInput" class="input-section">
          <input class='input_input' :modle="content" focus="auto" placeholder="请输入内容" @input='bindInputMsg'  />
         <view style="height:110rpx;width:170rpx;display:flex; align-items: center;justify-content: center;">
            <button class="send_button" size="mini" @click="add(item,article.id)">添加</button>
           </view>
        </view>
        <view class="replay-list">
          <block v-if="item.children.lenght>2">
            <view class="replay-item">
              <block v-for="(item2,i2) in item.children" :key="i2">
                <view class="replay-user">
                  <view class="item-left">
                    <image class="ava-com" :src="item2.author.headPortait" @click="goUserHome(item2.author.id)" mode=""></image>
                    <view class="item-connent">
                      <view class="connent-top">
                        {{item2.author.username}}
                      </view>
                        <text class="content">{{item2.content}}</text><text class="time">{{item2.createDate}}</text>
                      </view>
                  </view>
                </view>
              </block>
            </view>
            <view class="unfold-btn" @click="chooseUnfold" hidden="isOpen" data-value="item.isOpen" data-key="list1.[i]">展开{{item2.children.length - 1}}条回复</view>
            <view class="unfold-btn" @click="chooseUnfold" hidden="!isOpen" data-value="item.isOpen" data-key="list1.[i]">收起{{item2.children.length - 1}}条回复</view>
          </block>
          <!-- <block v-else> -->
            <block v-for="(item2,i2) in item.children" :key="i2">
              <view class="replay-user">
              <view class="item-left">
                <image class="ava-com" :src="item2.author.headPortait" @click="goUserHome(item2.author.id)" mode=""></image>
                <view class="item-connent">
                  <view class="connent-top">
                    {{item2.author.username}}
                  </view>
                    <text class="content">{{item2.content}}</text><text class="time">{{item2.createDate}}</text>
                  </view>
              </view>
              <view class="caozuo">
                <text @click="jubao(item.id)" class="jubao">举报</text>
              </view>
              </view>
            </block>
          <!-- </block> -->
        </view>
    </view>
    <view class="tixing">
      已经到底啦~~~
    </view>
  </view>
</template>

<script>
  export default {
    name:"my-comment",
    data() {
      return {
        //文本框的显示
         isOpen: true,
        active:0,
        isCollection:0,
        isShowInput:false,
        content:'',
        authorId:'',
        touserId:'',
        articleId:'',
         collectlist:{},
      };
    },
    props:['list1','getCommentList','article'],
   // lifetimes:{
     created(){
       console.log(22);
       let id =wx.getStorageSync('id')
       this.authorId=id
       // console.log(res);
       // console.log(this.articleId);
       console.log(this.authorId);
     },
     onShow() {
       
     },
   // },
    methods:{
      chooseUnfold(){
        this.isOpen=!this.isOpen
      },
      //将时间戳转换成日期格式
          replay(item){
            // console.log(item);
            this.isShowInput=!this.isShowInput  
            this.authorid=item.author.id
            this.authorname=item.author.username
          },
          //监听输入的值
          bindInputMsg(e){
            console.log(e.detail.value);
            this.content=e.detail.value
          },
          // 添加评论二级评论
          add(item,id){
           if(wx.getStorageSync('username')==''||wx.getStorageSync('id')=='') return uni.$showMsg('您还未登录，请先登录！')
           console.log(this.articleId);
           if(this.content==''){
            return uni.$showMsg('你看看是不是没有输入文字呢')
           }
            this.isShowInput=false
            const res=uni.request({
              url:'http://eg2ax8.natappfree.cc/comment/create',
              method:'POST',
              data:{
                articleId:id,
                 authorId:this.authorId,
                 toUserId:item.author.id,
                 parentCommentId:item.id,
                 content:this.content
              },
              header:{ Authorization:wx.getStorageSync('token') },
                  success: (res) => {
                      console.log(res.data);
                      if(res.data.code!=200) return uni.$showMsg("发表失败！")
                      uni.$showMsg("发表成功！")
                     this.getCommentList(id)
                     // this.onShow()
                     uni.reLaunch({
                       url:'/subpkg/my-article/my-article?id='+id
                     })
                  }
            })
            },
          //添加一级评论
         async addleave(id){
           if(wx.getStorageSync('username')==''||wx.getStorageSync('id')=='') return uni.$showMsg('您还未登录，请先登录！')
            // console.log(wx.getStorageInfo('username'));
            if(this.content==''){
             return uni.$showMsg('你看看是不是没有输入文字呢')
            }
           else{
             let cmt1={
                 articleId:id,
                 authorId:this.authorId,
                 toUserId:null,
                 parentCommentId:null,
                 content:this.content
               }
             const res=uni.request({
               url:'http://eg2ax8.natappfree.cc/comment/create',
               method:'POST',
               data:cmt1,
               header:{ Authorization:wx.getStorageSync('token') },
                   success: (res) => {
                       console.log(res.data);
                       if(res.data.code!=200) return uni.$showMsg("发表失败！")
                       uni.$showMsg("发表成功！")
                       
                      // this.onShow()
                      uni.reLaunch({
                        url:'/subpkg/my-article/my-article?id='+id
                      })
                      // this.onShow()
                   }
             })
           }
          },
          //隐藏输入框
          onHideInput(){
            this.isShowInput=false
          },
          jubao(id){
            wx.showModal({
              title: '提示',
              content: '确定要举报该条评论吗',
              success (res) {
                if (res.confirm) {
                  const res= uni.$http.post('/comment/commentReport/'+id)
                  .then(res=>{
                    if(res.statusCode!=200) return uni.$showMsg("举报失败！")
                    uni.$showMsg("举报成功！")
                    console.log(res);
                  })
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          },
          //去用户主页
          goUserHome(id){
            if(id==wx.getStorageSync('id')){
              uni.navigateTo({
                url:'/pages/my/my'
              })
            }else{
              uni.navigateTo({
                url:'/subpkg/user-home/user-home?id='+id
              })
            }
          },
          //删除该条评论
          delpl(id){
          wx.showModal({
                title: '提示',
                content: '确定要删除吗？',
                success: function (sm) {
                  if (sm.confirm) {
                      // 用户点击了确定 可以调用删除方法了
                     const res=uni.$http.delete('')
                      // });
                    } else if (sm.cancel) {
                      console.log('用户点击取消')
                    }
                  }
                }) 
          }
    },
  }
</script>

<style lang="scss">
  .my-comment{
    background-color: #fff;
  }
  .comment-box{
    width: 100%;
    border-top: 1px solid #d5e3d4;
    margin-top: 20rpx;
    margin-bottom: 20rpx;
  }
  .author{
    margin-top: 20rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-bottom: 30rpx;
  }
  .author-left{
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .img{
    width: 100rpx;
    height: 100rpx;
    border-radius: 50%;
  }
  // text{
  //   font-size: 30rpx;
  //   margin-top: 10rpx;
  // }
  .author-right{
    display: flex;
    margin-left: 20rpx;
  }
  .input{
    border-radius: 20rpx;
    border: 1px solid #cad7c5;
    padding-left: 10rpx;
    font-size: 34rpx;
    height: 70rpx;
  }
  .input-item{
    // width: 60rpx;
    background-color: #d5e3d4;
    border-radius: 30rpx;
    height: 70rpx;
    line-height: 70rpx;
    font-size: 24rpx;
    padding: 0 20rpx;
    margin-left: 10rpx;
    // color: #cfefe5;
  }
    .comment-item{
      display: flex;
      // height: 120rpx;
      justify-content: space-between;
      // background-color: #faf6df;
      align-items: center;
      margin-bottom: 20rpx;
      margin-top: 20rpx;
      margin-left: 30rpx;
      // border-bottom: 1px solid #d5e3d4;
    }
    .item-left{
      display: flex;
    }
    .ava-com{
      width: 80rpx;
      height: 80rpx;
      border-radius: 50%;
      margin-right: 10rpx;
    }
    .item-connent{
      display: flex;
      flex-direction: column;
      margin-left: -10rpx; 
    }
    .connent-top{
      font-size: 28rpx;
      color: #707e60;
    }
    .content{
      font-size: 30rpx;
      // color: ;
    }
    .connent-bottom{
      font-size: 34rpx;
    }
    .caozuo{
      display: flex;
    }
    .replay{
      font-size: 24rpx;
      color: #707e60;
      margin-right: 20rpx;
    }
    .jubao{
      font-size: 24rpx;
      color: crimson;
      margin-right: 20rpx;
    }
    .time{
      // margin-left: 20rpx;
      font-size: 26rpx;
      color: #cad7c5;
    }
    .likepl{
     font-size: 26rpx;
    }
    .delpl{
      font-size: 35rpx;
      color: red;
    }
    .replay-list{
      display: flex;
      flex-direction: column;
      width: 80%;
      margin-left: 70rpx;
      
      }
      .replay-user{
        display: flex;
        // height: 100rpx;
        align-items: center;
        justify-content: space-between;
        margin-top: 20rpx;
        // border-bottom: 1rpx solid #d5e3d4;
        }
      .ava-com{
          width: 70rpx;
          height: 70rpx;
          border-radius: 50%;
          margin-right: 10rpx;
        }
      .item-connent{
        display: flex;
        flex-direction: column;
        margin-left: 10rpx;
      }
      .connent-top{
        font-size: 30rpx;
        color: #707e60;
      }
      .connent-bottom{
        font-size: 30rpx;
      }
      
      .input-section {
          // position: absolute;
          display: flex;
          align-items: center;
          height: 110rpx;
          bottom: 0rpx;
          // left: 0rpx;
          // right: 0rpx;
          z-index: 500;
          background: #e4eac4;
      }
       
      .input_input {
          background: #e4eac4;
          margin-top: 12rpx;
          z-index: 500;
          width: 580rpx;
          height: 110rpx;
          padding-left: 35rpx;
       
      }
      .tixing{
        // border-top: 1px solid #cad7c5;
        margin-top: 70rpx;
        text-align: center;
        padding-top: 50rpx;
        width: 100%;
        height: 400rpx;
        color: #d5e3d4;
        font-size: 30rpx;
        border-top: 1px solid #e4eac4;
      }
</style>
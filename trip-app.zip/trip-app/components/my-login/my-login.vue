<template>
  <view>
    !-- 商品评价详情 E -->
    <view class="appraise-user">
      <view class="possess-layout margin-layouts">
        <view class="main">
          <view class="appraise-detail-top">共{{appraiseList.length}}条评论</view>
          <block wx:for="{{appraiseList}}" wx:key="index1" wx:for-index="index1">
            <view>
              <view class="username-appraise-top">
                <view class="username">
                  <image src="{{item.img}}"></image>
                  <view>{{item.username}}</view>
                </view>
                <view>
                  <image class="praise" src="{{item.change? '../../../img/icon/icon-give-a-like-red.png': '../../../img/icon/icon-give-a-like.png'}}" data-curindex="{{index1}}" bindtap="praiseThiss"></image>
                  <view class="amount {{item.change? 'hover-active': ''}}">{{item.praise}}</view>
                </view>
              </view>
            </view> 
            <view class="appraise-content"><text>{{item.appraise_content}}</text><text>{{item.time}}</text></view>
            <view class="reply-username">
              <block wx:if="{{item.reply_list.length > 2}}">
                <view class="reply-usernames {{item.isOpen? 'reply-usernames-active': ''}}">
                  <block wx:for="{{item.reply_list}}" wx:key="index2" wx:for-index="index2">
                    <view class="username-appraise-tops">
                      <view class="username">
                        <image src="{{item.img}}"></image>
                        <view>{{item.nickname}}</view>
                      </view>
                      <view>
                        <image class="praise" src="{{item.changes? '../../../img/icon/icon-give-a-like-red.png': '../../../img/icon/icon-give-a-like.png'}}" data-curindex="{{index1}}" data-curindexs="{{index2}}" bindtap="praiseThisss"></image>
                        <view class="amount {{item.changes? 'hover-active': ''}}">{{item.praise}}</view>
                      </view>
                    </view>
                    <view class="appraise-content"><text>{{item.reply_content}}</text><text>{{item.time}}</text></view>
                  </block>
                </view>
                <view class="unfold-btn" bindtap="chooseUnfold" hidden="{{item.isOpen}}" data-value="{{item.isOpen}}" data-key="appraiseList.[{{index1}}]">展开{{item.reply_list.length - 1}}条回复</view>
                <view class="unfold-btn" bindtap="chooseUnfold" hidden="{{!item.isOpen}}" data-value="{{item.isOpen}}" data-key="appraiseList.[{{index1}}]">收起{{item.reply_list.length - 1}}条回复</view>
              </block>
              <block wx:else>
                <block wx:for="{{item.reply_list}}" wx:key="index2" wx:for-index="index2">
                  <view class="username-appraise-top">
                    <view class="username">
                      <image src="{{item.img}}"></image>
                      <view>{{item.nickname}}</view>
                    </view>
                    <view>
                      <image class="praise" src="{{item.changes? '../../../img/icon/icon-give-a-like-red.png': '../../../img/icon/icon-give-a-like.png'}}" data-curindex="{{index1}}" data-curindexs="{{index2}}" bindtap="praiseThisss"></image>
                      <view class="amount {{item.changes? 'hover-active': ''}}">{{item.praise}}</view>
                    </view>
                  </view>
                  <view class="appraise-content"><text>{{item.reply_content}}</text><text>{{item.time}}</text></view>
                </block>
              </block>
            </view>
          </block>
        </view>
      </view>
    </view>
     
    <view class="end">
      - 这里就到底了哦 -
    </view>
  </view>
</template>

<script>
  export default {
    name:"my-login",
    data() {
      return {
        
      };
    }
  }
</script>

<style lang="scss">

</style>
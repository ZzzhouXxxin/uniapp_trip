<template>
 <view>
   <view class="search-container" :style="{height:navHeight+'px'}">
     <view class="search-box" @click="searchHander" >
        <uni-icons class="search-icon" type="search" color="#acb9a2" size="17"></uni-icons>
         <text class="title">请输入景区名称/关键字</text>
     </view>
     
   </view>
 </view>
</template>

<script>
  export default {
    name:"my-search",
    data() {
      return {
     
      };
    },
    props:['navHeight'],
    methods: {
      searchHander() {
        this.$emit('click')
      }
    },
    
  }
</script>

<style lang="scss">
.search-container{
   // height: 50px;
    // padding: 0 10px;
    display: flex;
   margin-top: 5px;
    // align-items: center;
  .search-box{
    border: 1px solid #acb9a2;
    width: 60%;
    // height: 35px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    padding: 4px 0 4px 10px;
    // padding-left: 10px;
    // margin-top: 5px;
    .title{
      color: #acb9a2;
      font-size: 13px;
      margin-left: 5px;
    }
  }
}
</style>
<template>
  <view>
    <view class="message-box">
      <view class="flex">
        <input type="text" class="sendmessage" placeholder="聊聊天吧!" @input="sendmessage">
        <view class="icon-box">
           <image class="sendicon" src="../../static/tabs_icon/input-1.png" mode=""></image>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
  export default {
    name:"send",
    data() {
      return {
        
      };
    }
  }
</script>

<style lang="scss">
.message-box{
     width: 100%;
     position: fixed;
     bottom: 0;
     padding-bottom: 20px;
     background-color: #d5e3d4;
   }
   .flex{
     text-align: center;
     align-items: center;
     justify-content: space-around;
     display: flex;
   }
   .sendmessage{
     width: 80%;
     padding: 10rpx;
     border: 1px solid #fff;
     border-radius: 40rpx;
   }
   .icon-box{
     // margin-left: 20rpx;
     width: 60rpx;
     height: 60rpx;
     background-color: #d5e3d4;
     border-radius: 20rpx;
     border: 1px solid #fff;
   }
   .sendicon{
     width: 40rpx;
     height: 40rpx;
     padding-top: 10rpx;
     padding-right: 10rpx;
   }
   .icon-box:hover{
     background-color: #fff;
     border: 1px solid #d5e3d4;
     animation: drop 3s infinite;
        @keyframes drop{ /*原图，放大一倍，再恢复到原图 */
     0%{
     	transform:scale(1); /*transform：2D、3D转换,旋转、缩放、移动、倾斜*/
     }
     30%{
     	transform:scale(1.125);/*扩大到4倍*/
     }
     to{
     	transform: scale(1);
     }
   }
   }
</style>
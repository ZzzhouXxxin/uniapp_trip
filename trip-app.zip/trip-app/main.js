
// #ifndef VUE3
import Vue from 'vue'
import App from './App'
//引入对消息的封装
import {$showMsg} from 'util/Msg.js'
// import request from 'api/request.js'
//模拟mock
// import '@/util/mock.js'
// 按需导入 $http 对象
import { $http } from '@escook/request-miniprogram'

//挂载
uni.$http=$http
// 配置请求根路径
$http.baseUrl = 'http://eg2ax8.natappfree.cc'
//拦截 预处理
// $http.interceptors.request.use(config => {
//   // console.log(config);
//   config.headers.Authorization = wx.getStorageSync('token')
//   return config
// })
//请求开始前做一些时
// $http.beforeRequest=function(options){
//   uni.showLoading({
//     title:'数据加载中'
//   })
// }
//请求结束后
$http.afterRequest = function () {
  uni.hideLoading()
}
Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App,
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
import App from './App.vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif
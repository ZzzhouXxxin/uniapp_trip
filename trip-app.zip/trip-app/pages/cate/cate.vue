<template>
  <view>
    <view class="top-box">
      <!-- 状态导航栏 -->
      <view class="top-nav" :style="{height:stateHeight+'px'}">
        
      </view>
        <my-search></my-search>
      <view class="allaticle">
        <view :class="['aticle-attention' ,currentpage==0 ? 'active' : '']" data-current="0" @click="switchnav">
          关注
        </view>
        <view :class="['aticle-all' ,currentpage==1 ? 'active' : '']" data-current="1" @click="switchnav">
          分类
        </view>
      </view>
    </view>
        <view class="swiper-item" :hidden="currentpage==1">
          <article-list :list="attantionlist"></article-list>
        </view>
        <view class="swiper-item" :hidden="currentpage==0">
          <!-- 一级分类名称 城市分类 -->
        <view class="cate1-box">
          <scroll-view class="scroll-view-x" scroll-x="true" :style="{width:ww+'px'}">
             <block v-for="(item,i) in cateList" :key="i">
               <view :class="['top-scroll-item', item.id === select ? 'select' : '']" @click="changeitem(item.id)">{{item.cityName}}</view>
             </block>
           </scroll-view>
        </view>
            <!-- 二级该城市所有的文章 -->
             <scroll-view class="scroll-view-y" scroll-y="true" :style="{height: wh+'px'}" :scroll-top="scrollTop">
              <article-list :list="cateList2"></article-list>
            </scroll-view>
        </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //全部分类列表
        cateList:[],
        cateList2:[],//二级分类 该城市的所有文章
        //所有我关注用户的文章
        attantionlist:[],
        currentpage:1,
        navHeight: 0,
        stateHeight: 0,
        ww:0,//系统宽度
        wh:0,//系统高度
        //当点击分类，其赋予select属性
        select:1
      };
    },
    onLoad() {
      this.fn(),
      console.log(this.ww);
      console.log(this.stateHeight);
      var id=wx.getStorageSync('id')
      this.getCateList()
      this.getCityList(1)
      this.getAttanList(id)
    },
    methods:{
      //  获取状态栏信息
      fn() {
        let ww=0;
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;	//  获取胶囊高度
          const sysInfo=uni.getSystemInfoSync()
          this.wh=sysInfo.windowHeight 
          this.ww=sysInfo.windowWidth
          this.stateHeight=sysInfo.statusBarHeight
           this.navHeight=navHeight
      },
    //监听导航栏的变化 全部 和关注 最顶部的导航栏
    switchnav(e){
      // console.log(e.currentTarget.dataset.current);
      this.currentpage=e.currentTarget.dataset.current;
    },
    //获取全部分类数据
   async getCateList(cb){
      const {data:res}=await uni.$http.get('/city')
      if(res.code!=200) return uni.$showMsg("获取分类数据失败！")
      // console.log(res);
      this.cateList=res.data
    },
    changeitem(id){
      // console.log(i);
      this.select=id;
      this.getCityList(id)
      // this.cateList2=this.cateList[i].children
    },
    async getAttanList(id){
      const {data:res}=await uni.$http.get('/articles/Articles_like/'+id)
      this.attantionlist=res.data
      console.log(res);
    },
    //获取某些城市的列表
   async getCityList(id){
     console.log(id);
      const {data:res}=await uni.$http.get('/city/'+id)
      // console.log(11);
      if(res.code!=200) return uni.$showMsg("请求失败")
      console.log(res);
      this.cateList2=res.data
    },
    //下拉刷新
    onPullDownRefresh(){
      this.cateList2=[]
      // 2. 重新发起请求
        this.getCateList(() => uni.stopPullDownRefresh())
    }
    }
  }
</script>

<style lang="scss">
.allaticle{
  display: flex;
  justify-content: center;
  margin-top: 7px;
  .aticle-attention{
    font-size: 12px;
    padding: 5px 15px;
    margin-right: 10px;
    color: #aaa;
  }
  .aticle-all{
    font-size: 12px;
    padding: 5px 15px;
    margin-left: 10px;
    color: #aaa;
  }
  .active{
     // background-color: #d5ddc1;
     color: #707e60;
     font-size: 16px;
     font-weight: bold;
  }
}
.scroll-view-x{
  white-space: nowrap;
   .top-scroll-item{
      display: inline-block;
      padding: 8rpx 15rpx;
      // background-color: #707e60;
      margin-left: 10rpx;
      font-size: 14px;
   }
   .select{
     font-size: 16px;
     font-weight: 800;
     color: #707e60;
     border-bottom:5rpx solid #707e60;
   }
}
.top-box{
  position: sticky;
  top:0;
  background-color: #fff;
  z-index: 9999;
}
.cate1-box{
   // 设置定位效果为“吸顶”
    position: sticky;
    // 吸顶的“位置”
    top: 200rpx;
    // 提高层级，防止被轮播图覆盖
    z-index: 999;
    background-color: #fff
}
.scroll-view-y{
  background-color: #707e60;
  margin-top: 10rpx;
}
</style>

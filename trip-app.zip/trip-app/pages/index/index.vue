<template>
	<view class="home">
    <!-- 顶部自定义导航栏 -->
    <view class="top-box">
      <view class="top-nav" :style="{height:stateHeight+'px'}">
        
      </view>
        <my-search :navHeight="navHeight" @click="goSearch"></my-search>
    </view>
  <!-- 轮播图 -->
  <swiper
    autoplay="true" interval="5000" duration="500">
    <block v-for="(item,i) in swiperList" :key="i">
      <swiper-item class="swiperitem">
        <image :src="item" mode="widthFix"></image>
      </swiper-item>
    </block>
  </swiper>
  <view class="index-main">
    <view class="x-scroll-view">
       <scroll-view scroll-x="true">
         <view @click="switchNav(0)" :class="['x-scroll-item',0 === active ? 'active' : '']">
           推荐
         </view>
        <block v-for="(item,i) in tagList" :key="item.id">
          <view @click="switchNav(item.id)"  :class="['x-scroll-item',item.id === active ? 'active' : '']">
            {{item.tagName}}
          </view>
        </block>
       </scroll-view>
     </view>
     <view class="index-item" v-if="active==0">
       <view class="hot-list">
         <view class="hot-list-top">
           <view class="top-left">
             <text>热门景区</text>
             <image class="hot" src="../../static/hot.png" mode=""></image>
           </view>
         </view>
         <view class="hot-list-content">
           <view class="hot">
              <scroll-view scroll-x="true">
               <block v-for="(item,i) in hotlist" :key="item.id">
                 <view class="content-item">
                   <view @click="goHotList(item)"  class="item">
                    <image :src="item.picture" mode=""></image>
                    <text class="name">{{item.name}}</text>
                   </view>
                 </view>
               </block>
              </scroll-view>
            </view>
             <view class="hot">
              <scroll-view scroll-x="true">
               <block v-for="(item,i) in hotlist1" :key="item.id">
                 <view class="content-item">
                   <view @click="goHotList(item)"  class="item">
                    <image :src="item.picture" mode=""></image>
                    <text class="name">{{item.name}}</text>
                   </view>
                 </view>
               </block>
              </scroll-view>
            </view>
         </view>
       </view>
       <view class="all-list">
         <view class="all-list-top">
           <view class="all-top-left">
             <text>全部游记</text>
           </view>
           <view class="all-top-right" @click="gocate">
             <text>分类</text>
             <image src="../../static/right-jt.png" mode=""></image>
           </view>
         </view>
         <view class="sort-box">
           <view @click="getnew" :class="['hot',0=== selected ? 'selected' : '']">
             最新
           </view>
           <view  @click="gethot" :class="['hot',1=== selected ? 'selected' : '']">
             最热
           </view>
           <view  :class="['hot',2=== selected ? 'selected' : '']">
             评论多
           </view>
         </view>
         <view class="all-list-content">
          <article-list :list="allList"></article-list>
         </view>
       </view>
     </view>
     <view class="index-item" v-else-if="active==1">
       <article-list :list="tagitems"></article-list>
     </view>
     <view class="index-item" v-else="active==2">
        <article-list :list="tagitems"></article-list>
     </view>
  </view>
  </view>
</template>

<script>
	export default {
		data() {
			return {
        //轮播图列表
        swiperList:[
          "../../static/swiper4.jpg",
          "../../static/swiper5.jpg",
          "../../static/swiper7.jpg",
          "../../static/swiper/1.png",
        ],
        //标签列表
        tagList:[],
        tagName:['推荐'],
        //热门景区列表
        hotlist1:[],
        hotlist:[],
        newlist:[],
        //按最热文章查找
        articlehotList:[],
        //所有文章列表
        allList:[],
        //滚动条距离顶部的距离
        scrollTop: 0,
        navHeight: 0,
        //标签的是否选中
        active: 0,
        //最热最新是否选中
        selected:0,
        stateHeight: 0,
        tagitems:[],
        queryObj:{
          pageNum:1,
          pageSize:6,
        },
        isLoading:false
			}
		},
    onLoad(){
      wx.showShareMenu({
          withShareTicket:true,
          //设置下方的Menus菜单，才能够让发送给朋友与分享到朋友圈两个按钮可以点击
          menus:["shareAppMessage","shareTimeline"]
      })
      this.fn(),
      this.getHotList(),
      //获取taglist
      this.getTaglist(),
      this.getallList()
      // const sysInfo=uni.getSystemInfoSync()
      // this.wh=sysInfo.windowWidth 
      // console.log(this.wh);
    },
		methods: {
      //  获取状态栏信息
      fn() {
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;	//  获取胶囊高度
          let top = 0;
      	wx.getSystemInfo({
            success(res) {
              console.log("状态栏：" + res.statusBarHeight)
              stateHeight = res.statusBarHeight;
            }
          })
          // top = wx.getMenuButtonBoundingClientRect().top -stateHeight;	//  获取top值
      	//  然后将取到的值返回在data里面
            // this.navHeight=navHeight + top*2,		//  导航栏高度
           this.navHeight=navHeight
            this.stateHeight=stateHeight		
              //  状态栏高度
      },
      //点击搜索框
      goSearch(){
        uni.navigateTo({
          url:'/subpkg/search/search'
        })
      },
      switchNav(id){
        console.log(id);
        this.active=id,
        this.getTagItem(id)
        // this.getTagItem(id)
        this.scrollTop = this.scrollTop ? 0 : 1
      },
      async getTagItem(id){
        const {data:res}=await uni.$http.get('/tags/'+id)
        // if(res.code!=200) return uni.$showMsg("请求失败！")
        this.tagitems=res.data
         // console.log(res);
      },
    async  getHotList(){
        const {data:res}=await uni.$http.get('/scenic')
        // if(res.data.code!=200) return uni.$showMsg("获取失败！")
        this.hotlist=res.data.data
         this.hotlist1=this.hotlist.splice(9,9)
        this.hotlist=this.hotlist.slice(0,9)
        console.log(this.hotlist1);
      },
      //获取标签列表
     async getTaglist(){
        const {data:res}=await uni.$http.get('/tags')
        // console.log(res);
        // if(res.code!=200) return uni.$showMsg("请求失败！")
        // this.tagName=[...this.tagName,...res.data.tagName]
        this.tagList=res.data 
      },
      //获取所有文章
    async getallList(cb){
      //节流阀
      console.log(this.queryObj);
        this.isLoading=true
        const {data:res}=await uni.$http.post('/articles',this.queryObj)
         this.isLoading=false
         cb && cb()
        // console.log(res);
        // if(res.code!=200) return uni.$showMsg("请求失败！")
        // this.allList=res.data
        this.allList = [...this.allList, ...res.data]
         // if(res.data='') return uni.$showMsg("已经到底啦！")
      },
      // 触底的事件
      onReachBottom() {
       // 判断是否还有下一页数据
        if (this.queryObj.pageNum * this.queryObj.pageSize >= this.total) return uni.$showMsg('数据加载完毕！')
      
        // 判断是否正在请求其它数据，如果是，则不发起额外的请求
        if (this.isloading) return
        // 让页码值自增 +1
        this.queryObj.pageNum += 1
        // 重新获取列表数据
        this.getallList()
        this.gethot()
        this.getnew()
      },
      //下拉刷新
      onPullDownRefresh(){
        this.queryObj.pageNum=1
        this.allList=[]
        this.newList=[]
        // 2. 重新发起请求
        this.getallList(() => uni.stopPullDownRefresh())
        // this.getnew(() => uni.stopPullDownRefresh())
        // this.gethot(() => uni.stopPullDownRefresh())
      },
      goHotList(item){
        uni.navigateTo({
          url:'/subpkg/article_list/article_list?id='+item.id
        })
      },
     async getnew(){
       this.selected=0
        console.log(this.queryObj);
          this.isLoading=true
          const {data:res}=await uni.$http.post('/articles/new',this.queryObj)
           this.isLoading=false
           // cb && cb()
          console.log(res);
          if(res.code!=200) return uni.$showMsg("请求失败！")
          // this.allList=res.data
          // this.allList = [...this.allList, ...res.data]
          // uni.redirectTo({
          //   url:'/pages/index/index'
          // })
      },
     async gethot(){
       this.selected=1
        console.log(this.queryObj);
          this.isLoading=true
          const {data:res}=await uni.$http.post('/articles/hot',this.queryObj)
           this.isLoading=false
           // cb && cb()
          console.log(res);
          if(res.code!=200) return uni.$showMsg("请求失败！")
          // this.allList=res.data
          // this.allList = [...this.allList, ...res.data]
          // uni.redirectTo({
          //   url:'/pages/index/index'
          // })
      },
      //跳转到分类页面
      gocate(){
        uni.redirectTo({
          url:'/pages/cate/cate'
        })
      }
		}
	}
</script>

<style lang="scss">
  .home{
    width: 100%;
    height: 100%;
    // background-color: #d5ddc1;
    .top-box{
      position: sticky;
      top:0;
      background-color: #fff;
      z-index: 9999;
    }
    swiper{
      margin: 20rpx 10rpx 0 10rpx;
      .swiperitem{
        width: 100%;
        height: 100%;
        border-radius: 20rpx;
        image{
          width: 100%;
          height: 100%;
        }
      }
    }
    .x-scroll-view{
      // width: 375px;
      white-space:nowrap;
      position: sticky;
      // 吸顶的“位置”
      top: 120rpx;
      border-radius: 8px;
      // 提高层级，防止被轮播图覆盖
      z-index: 999;
      background-color: #fff;
    }
    .x-scroll-item{
       display: inline-block;
     padding: 10rpx 30rpx;
      margin-left: 20rpx;
      border-radius: 30rpx;
      color: #95a887;
      font-size: 34rpx;
    }
    .active{
      font-size: 16px;
      border-radius: 20rpx;
      border-bottom:10rpx solid #95a887;
      background-color: #acb9a2;
      color: #fff;
    }
  // .index-top{
  //   .top-nav{
  //     height: stateHeight px;
  //   }
  // }
  .index-main{
    margin-top: 20rpx;
  }
  .index-item{
    margin-top: 10rpx;
    background-color: #fffdf6;
    .hot-list{
      margin: 15rpx;
      .hot-list-top{
        height: 60rpx;
        display: flex;
        justify-content: space-between;
        // background-color: #95a887;
        .top-left{
          align-items: center;
          vertical-align:middle;
          color: #95a887;
        }
        image{
          width: 36rpx;
          height: 36rpx;
          line-height: 60rpx;
        }
      }
    .hot-list-content{
      .hot{
        white-space:nowrap;
      }
      .content-item{
        display: inline-block;
        // display: flex;
        // width: 33%;
        width: 240rpx;
        height: 240rpx;
        margin-right: 5rpx;
        margin-top: 10rpx;
       .item{
         width: 100%;
         height: 100%;
         position: relative;
         background-color: #95a887;
         border-radius: 20px;
         image{
           width: 100%;
           height: 100%;
            border-radius: 20px;
         }
         .name{
           position: absolute;
           top: 50%;
           left: 50%;
           color: aliceblue;
           font-size: 16px;
           font-family: arial;
           transform: translateY(-30%);
           transform: translateX(-50%);
         }
       }
      }
    }
    }
    .all-list{
      margin-top: 30rpx;
      margin-left: 15rpx;
      .all-list-top{
        margin-bottom: 20rpx;
        display: flex;
        justify-content: space-between;
        .all-top-left{
          text{
            color: #95a887;
          }
        }
        .all-top-right{
          margin-right: 10rpx;
          display: flex;
          align-items: center;
          text{
              font-size: 28rpx;
              color: #95a887;
          }
          image{
            width: 30rpx;
            height: 30rpx;
          }
        }
      }
      .sort-box{
        height: 60rpx;
        display: flex;
        justify-content: space-around;
        margin-bottom: 10rpx;
        border-bottom: 1px solid #acb9a2;
        .hot{
          padding: 10rpx 20rpx;
          font-size: 26rpx;
          border-radius: 40rpx;
          color: #acb9a2;
          // background-color: #acb9a2;
        }
      }
    }
  }
  }
  .selected{
    color: #fffdf6;
    background-color: rgb(255,255,255)
  }
</style>

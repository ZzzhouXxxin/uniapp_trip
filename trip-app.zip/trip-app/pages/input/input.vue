<template>
  <view class="input-box">
  <view class="input-home">
    <view class="img-li" v-for="(item ,i) in imglist" :key="i">
      <image class="uploading-icon" :src="item" mode="" @click="previewImg"></image>
      <icon type="cancel" class="imgremove" @click="deleteImg"></icon>
    </view>
    <!-- 点击上传图片的图标 -->
    <view class="img-li" @click="uploadp">
      <image class="uploading-icon" src="../../static/upload.png" mode=""></image>
    </view>
  </view>
  <view class="write-home">
    <input class="title" maxlength="18" placeholder="请输入标题" @input="getTitle" :modle="title">
    <!-- <textarea class="content" minlength="3" maxlength="500" name="remark" 	show-confirm-bar  placeholder="来发表你的攻略吧....." @input="getContent" :modle="content"/> -->
      <editor id="editor" class="ql-container" placeholder="来发表你的攻略吧" @input="getContent">
      </editor>
  </view>
  <view class="en">
  		<scroll-view scroll-x="true" class="xh">
  			<view class="ac" :class="{ kun: tags.indexOf(i) != -1 }" v-for="(item,i) of tagList" :key="i" @click="appointment(i)">
  				<view class="">{{item.tagName}}</view>
  			</view>
  		</scroll-view>
  	</view>
  <view class="select">
    <view class="jd">
     <view class='top'>
       <view class='top-text'> 选择景点</view>
       <!-- 下拉框 -->
       <view class="select_box" v-if="select">
           <view class="box">
         <view class="select-item" v-for="(item,i) in jdlist" :key="i">
             <view class="select_one" @click="mySelect" :data-id="item.id" :data-name="item.name">{{item.name}}</view>
           </view>
         </view>
       </view>
     <view class="select-right">
       <view class='top-selected' @tap='bindShowMsg'>
         <text class="jd_name">{{jd_name}}</text>
         <!-- <image src='/images/xia.png'></image> -->
       </view>
       <!-- 下拉需要显示的列表 -->
       <!-- <view class="select_box" v-if="select">
           <view class="box">
         <view class="select-item" v-for="(item,i) in jdlist" :key="i">
             <view class="select_one" @click="mySelect" :data-id="item.id" :data-name="item.name">{{item.name}}</view>
           </view>
         </view>
       </view> -->
     </view>
     </view>
    </view>
  </view>

  <view class="submit">
    <button @click="submit" class="btn-submit">发布游记</button>
  </view>
</view>
</template>

<script>
  export default {
    data() {
      return {
        select: false,
        jd_name: '--请选择--',
        // grades: ['1班', '2班', '3班'],
        //上传的图片
        imglist:[],
        title:'',
        content:'',
        count:0,
        authorId:'',
        jdlist:[],
        scenicId:'',
        tagList:[],
        pics:[],
        tags:[
        ]
      };
    },
    onShow() {
      if(wx.getStorageSync("username")==''||wx.getStorageSync("id")==''){
        uni.$showMsg("未登录不能发表文章哦！请登录再来")
        
      }
    },
    onLoad(){
      // console.log(11);
      let id=wx.getStorageSync('id')
      this.authorId=id,
      // console.log(res);
      this.getTagelist(),
      this.getJdlist()
    },
    methods:{
      appointment(index) {
      					let that = this;
      					if (that.tags.indexOf(index) == -1 && that.tags.length<3) {
      						console.log(index); //打印下标
      						that.tags.push(index); //选中添加到数组里
                  console.log(this.tags);
      					}else if(that.tags.length==3 ||that.tags.indexOf(index), 1){
      						uni.showToast({
      							title:'最多只能选三个',
      							duration:1000,
      							icon:'none'
      						})
      						that.tags.splice(that.tags.indexOf(index), 1); //取消
      					}
      				},
      //获取景点列表
     async getJdlist(){
       const {data:res}=await uni.$http.get('/scenic')
       if(res.code!=200) return uni.$showMsg("请求失败！")
       console.log(res.data);
      this.jdlist=res.data.data
      },
      //点击显示和隐藏
      bindShowMsg(){
        this.select=!this.select
      },
      //我的选择
      mySelect(e){
        console.log(e.target.dataset.id);
        this.scenicId=e.target.dataset.id
        this.jd_name=e.target.dataset.name
        this.select=false
      },
     async getTagelist(){
      const {data:res}=await uni.$http.get('/tags')
      // console.log(res.data);
      if(res.code!=200) return uni.$showMsg("获取失败！")
      this.tagList=res.data
      },
      uploadp(){
        wx.showActionSheet({
          itemList: ['拍照','从相册中选择'],
          // itemColor:#95a887
          success: (res)=> {
           if(!res.cancel){
             if(res.tapIndex==0){//相机
               this.imgShow("camera")
             }else if(res.tapIndex==1){//相册中选取
               this.imgShow('album')
             }
           }
          },
          fail (res) {
            console.log(res.errMsg)
          }
        })
      },
      imgShow(type){
        let len=0;
        // console.log(this.imglist);
        if(this.imglist!=null){
          len=this.imglist.length
        }
        wx.chooseImage({
          count: 10-len,//能上传的最多图片
          sizeType: ['original', 'compressed'],
          sourceType: [type],
          success:(res)=> {
            wx.showToast({
              title:'正在上传.....',
              icon:"loading",
              mask:true,
              duration:1000
            })
            console.log(res.tempFilePaths);
            // tempFilePath可以作为 img 标签的 src 属性显示图片
            var imglist = res.tempFilePaths
            let tempFilePathsImg =this.imglist
            // //获取当前已经上传的图片
            var tempFilePathsImgs=tempFilePathsImg.concat(imglist)
            this.imglist=tempFilePathsImgs
            // this.imglist=res.tempFilePaths
            let that = this;
           this.imglist.forEach((item,i)=>{
             wx.uploadFile({
                   url: 'http://eg2ax8.natappfree.cc/upload', //仅为示例，非真实的接口地址
                   methods:'post',
                   filePath: this.imglist[i],
                   name: 'image',
                  header: {
                              "Content-Type": false,
                            },
                   success (res){
                     // let that=this
                     const data = res.data
                     that.pics.push(data)
                     // console.log(that.pics);
                   },
                   fail(res){
                     console.log(res);
                   }
                  
                 })
           })
          },
          fail:(res)=>{
            wx.showToast({
              title:'图片上传失败',
              icon:'none'
            })
            return 
          }
        })
      },
      //预览图片
      previewImg(e){
        let index=e.currentTarget.dataset.index;
       wx.previewImage({
         current: this.imglist[index], // 当前显示图片的 http 链接
         urls: this.imglist // 需要预览的图片 http 链接列表
       })
      },
      //点击删除
      deleteImg(e){
        console.log(e);
        var imglist=this.imglist
        var index=e.currentTarget.dataset.index;
        wx.showModal({
          title:'提示',
          content:'确认要删除这张照片吗？',
          success:(res)=>{
            if(res.confirm){
              console.log('点击了确认');
              imglist.splice(index,1);
            }else if(res.cancel){
              console.log('点击了取消');
              return false
            }
            this.imglist=imglist
          }
        })
      },
      //获取标题
      getTitle(e){
        // console.log(e.detail.value);
        this.title=e.detail.value
      },
      //获取内容
      getContent(e){
        console.log(e.detail.text);
        this.content=e.detail.text
      },
     async submit(e){
        if(this.content==''||this.title==''){
          uni.$showMsg("内容或标题不能为空！")
        }
       if(this.tags==''||this.scenicId==''){
         uni.$showMsg("请选择标签和分类")
       }
        else{
          console.log(this.pics);
          // let token=wx.getStorageSync('token')
          // console.log(token);
          const res=uni.request({
            url: 'http://eg2ax8.natappfree.cc/articles/publish',
            method:'POST',
            data:{
              pictures:this.pics,
              userId:this.authorId,
              title:this.title,
              content:this.content,
              scenicId:this.scenicId,
              tagsId:this.tags
            },
            header:{ Authorization:wx.getStorageSync('token') },
                success: (res) => {
                    console.log(res.data);
                    if(res.data.code!=200) return uni.$showMsg("发表失败！")
                    uni.$showMsg("发表成功！")
                    uni.redirectTo({
                      url:'/pages/my/my'
                    })
                }
          })
          // const {data:res}=await uni.$http.post('/articles/publish',{
          //   pictures:this.pics,
          //   userId:this.authorId,
          //   title:this.title,
          //   content:this.content,
          //   scenicId:this.scenicId,
          //   tagsId:this.tags
          // },
          
          }
        }
  },
    }
</script>

<style lang="scss">
  .input-box{
    margin-left: 15rpx;
    margin-right: 15rpx;
  }
.input-home{
  display: flex;
  .img-li {
    position: relative;
    width: 170rpx;
    height: 170rpx;
    margin-right: 5rpx;
    margin-bottom: 20rpx;
    margin-top: 3px;
    border: 1px solid #95a887;
  }
  .img-li:nth-child(4) {
    margin-right: 0;
  }
  .img-li:first-child {
    margin-right: none;
  }
  .img-li image {
    width: 100%;
    height: 100%;
  }
  .imgremove{
    position: absolute;
    top:0;
    right: 0;
  }
}
.write-home{
  margin: 5px;
  .title{
    padding: 10px 0;
    border-bottom: 1px solid #95a887;
    font-size: 34rpx;
  }
  .content{
    width: 100%;
    font-size: 30rpx;
    line-height: 20px;
  }
}
.submit{
  // width: 100%;
  width: 80%;
  position: fixed;
  bottom: 20rpx;
  .btn-submit{
    background-color: #95a887;
    width: 100%;
  }
}
.select{
     display: flex;
     // justify-content: space-between;
   }
   .label-right{
     background-color: #95a887;
     padding: 10rpx;
   }
   /* 顶部 */
   
   .top {
     width: 100vw;
     height: 80rpx;
     padding: 0 20rpx;
     line-height: 80rpx;
     font-size: 34rpx;
     // border-bottom: 1px solid #95a887;
   }
   
   .top-text {
     float: left;
   }
   
   /* 下拉框 */
   .jd_name{
     margin-left: 100rpx;
   }
   .top-selected {
     width: 50%;
     display: flex;
     // float: right;
     position: absolute;
     right: 40rpx;
     align-items: center;
     margin-right: 20rpx;
     // justify-content: space-between;
     border: 1px solid #95a887;
     padding: 0 10rpx;
     font-size: 30rpx;
     border-radius: 20rpx;
   }
   .select-right{
     position: relative;
   }
   /* 下拉内容 */
   
   .select_box {
     background-color: #fff;
     // padding: 0 20rpx;
     width: 50%;
     // float: right;
     position: absolute;
     // right: 0;
     left: 340rpx;
     bottom: 325rpx;
     z-index: 999;
     overflow: hidden;
     text-align: left;
     animation: myfirst 0.5s;
     font-size: 30rpx;
     border: 1px solid #95a887;
     border-radius: 10px;
   }
   // .select-item{
   //   position: absolute;
   //   // right: 0;
   //   right: 30rpx;
   // }
   .box{
     height: 270rpx;
     overflow-x: hidden;
     overflow-y: scroll;
   }
   .select_one {
     padding-left: 20rpx;
     width: 100%;
     height: 60rpx;
     position: relative;
     line-height: 60rpx;
     border-bottom: 1px solid #E6E6E6;
   }
   
   /* 下拉过度效果 */
   
   @keyframes myfirst {
     from {
       height: 0rpx;
     }
   
     to {
       height: 210rpx;
     }
   }
   
   /* 下拉图标 */
   
   .top-selected image {
     height: 50rpx;
     width: 50rpx;
     position: absolute;
     right: 0rpx;
     top: 20rpx;
   }
	.en {
    // position: fixed;
    // top: 5;
    margin: 40rpx 0;
    white-space:nowrap;
		width: 100%;
		padding:0 30rpx 0;
		box-sizing: border-box;
    }
    .ac{
      text-align: center;
      display: inline-block;
      width: 120rpx;
      margin: 0 15rpx;
      padding: 10rpx;
      border-radius: 20rpx;
      border: 1px solid #95a887;
      // background-color: #95a887;
    }
		// .xh {
		// 	display: flex;
		// 	justify-content: space-between;
		// 	align-items: center;
		// 	flex-wrap: wrap;
		// 	.ac {
		// 		width: 22%;
		// 		height: 60rpx;
		// 		line-height: 60rpx;
		// 		border: 2rpx solid #E6E6E6;
		// 		text-align: center;
		// 		margin-top: 30rpx;
		// 		font-size: 26rpx;
		// 		color: #666;
  //       border-radius: 20rpx;
		// 	}
		// }
	.kun {
		color: #fff !important;
    background-color: #95a887
	}

</style>

<template>
  <view>
    <view>
     <view class="login-bg">
       <image src="../../static/loginbg.jpg" mode="widthFix"></image>
       <text class="goback" @click="back">返回</text>
       <h1>welcome</h1>
        <view class="login-home">
           <view class="nav">
               <view :class="['left', logarig==1?'select':'']" @click="changeNav" data-code="1">
                 <text>登录</text>
               </view>
               <view :class="['right', logarig==0?'select':'']" @click="changeNav" data-code="0">
                 <text>注册</text>
               </view>
            </view>
               <!-- 登录 -->
            <view class="input-box" :hidden="logarig==0">
                   <view class="wei-input">
                   <image src="../../static/login/user.png" mode=""></image>
                     <input class="input" @input="handlesuername" :model="userFrom.username"  auto-focus placeholder="请输入手机号/登录名"/>
                   </view>
                   <view class="wei-input">
                     <image src="../../static/login/password.png" mode=""></image>
                     <input type="password" class="input" @input="handlepsw" :model="userFrom.password" auto-focus placeholder="请输入登录密码" />
                   </view>
                 </view>
             <!-- 注册 -->
            <view class="input-box" :hidden="logarig==1">
          
             <!-- <view class="wei-input">
                <image src="../../static/login/code.png" mode=""></image>
                <input class="input" auto-focus placeholder="请输入6位验证码"/>
                <text class="input-code" bindtap="getCode">{{codeText}}</text>
              </view> -->
              <view class="wei-input">
                <image src="../../static/login/password.png" mode=""></image>
                <input type="string" class="input" @input="handlesuername" :model="userInfo.username" auto-focus placeholder="用户名称"/>
              </view>
              <view class="wei-input">
                <image src="../../static/login/password.png" mode=""></image>
                <input type="password" class="input" @input="handlepsw" :model="userFrom.password" auto-focus placeholder="请输入密码"/>
              </view>
            </view>
           <view class="sumbit-btn">
             <button @click="submit" class="button" 
             >立即{{logarig==1?'登录':'注册'}}</button>
           </view>
           <view v-if="logarig==1" class="bottom">
             <text>____________________________________________</text>
             <image @click="towxLogin" src="../../static/wx.png" mode=""></image>
           </view>
        </view>
     </view>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //判断为登录还是注册
        logarig:1,
        // 用户信息
        userFrom:{
          // avatarUrl:'',
          username:'',
          password:'',
          // avator:'../../static/user.png',
          // sex:''
        },
        info:'',
        sessionId:''
      };
    },
    methods:{
      //微信登录
      towxLogin(){
        console.log(11);
       wx.login({
         
         success:(res)=>{
           
           var code = res.code
           // console.log(res);
           if(code){
             
           uni.$http.get('/user/getSessionId/'+code)
            .then((result)=>{
              console.log(result);
              // res.then(res1=>{
              //   console.log(res1);
              // })
              this.sessionId = result.data.data;
              wx.getUserInfo({
                 desc: '用于完善会员资料',
                success:(res=>{
                  // console.log(this.sessionId);
                  // console.log(res);
                  uni.$http.post('/user/authLogin',
                  {
                    sessionId:this.sessionId,
                    encryptedData:res.encryptedData,
                    iv:res.iv
                  })
                  .then(res1=>{
                    // this.info=r
                    console.log(res1.data.data);
                    this.info=res1.data;
                    if(this.info.code != 200)
                      return uni.$showMsg("登录失败！")
                    console.log(this.info.data.token);
                    uni.$showMsg("登录成功！")
                    wx.setStorageSync('token',this.info.data.token)
                    wx.setStorageSync('id',this.info.data.id)
                    // wx.setStorageSync('username',res.userInfo.username)
                    wx.setStorageSync('avatarUrl',res.userInfo.avatarUrl)
                    wx.setStorageSync('username',res.userInfo.nickName)
                    uni.$http.get('/test/'+this.info.data.id)
                   
                    // console.log(this.info);                
                    uni.redirectTo({
                      url:'/pages/my/my'
                    })
                  })
                })
              })
            })
           }
         }
       })
      },
      getUserInfo(){
        wx.getUserInfo({
           desc: '用于完善会员资料',
          success:(res=>{
            // console.log(this.sessionId);
            // console.log(res);
            uni.$http.post('/user/authLogin',
            {
              sessionId:this.sessionId,
              encryptedData:res.encryptedData,
              iv:res.iv
            })
            .then(res1=>{
              // this.info=r
              console.log(res1.data.data);
              this.info=res1.data;
              if(this.info.code != 200)
                return uni.$showMsg("登录失败！")
              console.log(this.info.data.token);
              uni.$showMsg("登录成功！")
              wx.setStorageSync('token',this.info.data.token)
              wx.setStorageSync('id',this.info.data.id)
              // wx.setStorageSync('username',res.userInfo.username)
              wx.setStorageSync('avatarUrl',res.userInfo.avatarUrl)
              wx.setStorageSync('username',res.userInfo.nickName)
              uni.$http.get('/test/'+this.info.data.id)
             
              // console.log(this.info);                
              uni.redirectTo({
                url:'/pages/my/my'
              })
            })
          })
        })
      },
      //登录注册状态栏
      changeNav(e){
        console.log(e); 
       let index = e.currentTarget.dataset.code;
          this.logarig=index
      },
      //从登录界面退出
      back(){
        this.login=2
      },
      //获取密码
      handlepsw(e){
        // console.log(e.detail.value);
         this.userFrom.password=e.detail.value
      },
      handlesuername(e){
        // console.log(e.detail.value);
         this.userFrom.username=e.detail.value
      },
      //注册和登录
     async submit(evt){
       if(this.logarig===1){
         const {data:res}=await uni.$http.post('/login',this.userFrom)
         if(res.code!=200) return uni.$showMsg("用户名或者密码不对！")
         // console.log(res);
         wx.setStorageSync('id',res.data.id)
         wx.setStorageSync('username',res.data.username)
           uni.$showMsg('登录成功')
           uni.$http.get('/test/'+res.data.id)
           uni.redirectTo({
             url:'/pages/my/my'
           })
       }else{
         const {data:res}=await uni.$http.post('/login/register',
               this.userFrom
               )
          if(res.code!=200) return uni.$showMsg("用户已使用")
          uni.$showMsg('注册成功！')
          wx.setStorageSync('id',res.data.id)
          wx.setStorageSync('username',res.data.username)
               // console.log(res);
          uni.redirectTo({
            url:'/pages/my/my'
          })
       }
      },
    }
  }
</script>

<style lang="scss">
.login-bg{
  position: relative;
  width: 100%;
  height: 100%;
  image{
    position: absolute;
    z-index: -1;
    top: 0;
    width: 100%;
    height: 100%;
  }
  .goback{
    position: absolute;
    z-index: 99;
    top: 30px;
    left: 10px;
  }
  h1{
    position: absolute;
    font-size: 30px;
    left: 20px;
    top: 50px;
    font-weight: 900;
    color: darkkhaki;
  }
  .login-home{
    position: absolute;
    z-index: 99;
    top: 150px;
    // margin-top: 50px;
    left: 50%;
    transform: translateX(-50%);
    width: 300px;
    // height: 200px;
    // background-color: #f1e0a8;
  }
}
.nav{
  // background-color: #fffbf6;
  display: flex;
  justify-content: space-around;
  align-items: center;
  .select{
    padding: 5px 35px;
    color: #fffbf6;
    background-color: #95a887;
    border-radius: 30px;
  }
}
 .input-box{
    margin-top: 20px;
    margin-left: 20px;
    .wei-input{
      position: relative;
      padding: 8px 0;
      margin-top: 10px;
      margin-bottom: 50px;
      image{
        position: absolute;
        // z-index: 99;
        top: 10px;
        width: 30px;
        height: 30px;
      }
      .input{
        // background-color: #dcdec0;
        position: absolute;
        left: 35px;
        border: 1px solid #dcdec0;
        padding: 8px 0;
        width: 200px;
        border-radius: 10px;
      }
    }
  }
.sumbit-btn{
  margin-top: 60px;
  .button{
    background-color: #95a887;
    color: #fffbf6;
  }
}
.bottom{
  position: relative;
  margin-top: 40px;
    text{
      color: #fffbf6;
    }
      image{
        position: absolute;
        position: absolute;
        top: 30px;
        left: 50%;
            margin-top: 40px;
         transform: translateX(-50%);
        right: 15px;
        top: 15px;
        width: 50px;
        height: 50px;
      }
  }
</style>

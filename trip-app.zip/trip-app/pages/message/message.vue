<template>
  <view>
   <view class="comment-item">
   <view class="item-left">
     <image class="ava-com" :src="userInfo.headPortait" ></image>
     <view class="item-connent">
       <view class="connent-top">
         {{userInfo.username}}
       </view>
         <!-- <text class="content">{{item.content}}</text>
         <text class="time">{{item.createDate}}</text> -->
     </view>
   </view>
      </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        userInfo:[]
      };
    },
    onLoad() {
      this.getUser()
    },
  methods:{
    async getUser(){
       const {data:res}=await uni.$http.get('/user/'+3)
       this.userInfo=res.data
     }
  }
  }
</script>

<style lang="scss">
 .comment-item{
      display: flex;
      // height: 120rpx;
      justify-content: space-between;
      // background-color: #faf6df;
      align-items: center;
      margin-bottom: 20rpx;
      margin-top: 20rpx;
      margin-left: 30rpx;
      // border-bottom: 1px solid #d5e3d4;
    }
    .item-left{
      display: flex;
    }
    .ava-com{
      width: 80rpx;
      height: 80rpx;
      border-radius: 50%;
      margin-right: 10rpx;
    }
    .item-connent{
      display: flex;
      flex-direction: column;
      margin-left: -10rpx; 
    }
</style>

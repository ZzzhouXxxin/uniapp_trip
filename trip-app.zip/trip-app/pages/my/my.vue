<template>
  <view class="my-container">
   <view v-if="userInfo.id!=''">
     <view class="my-top">
        <view class="my-bg">
          <image src="../../static/2.jpg" mode=""></image>
        </view>
        <view class="my-avter">
          <view class="box-list">
            <view class="box" @click="goFansList(userInfo.id)">
              <text class="wenzi">关注</text>
              <text class="number">{{Atttotal}}</text>
            </view>
            <view class="box" @click="goFansList(userInfo.id)">
              <text class="wenzi">粉丝</text>
              <text class="number">{{FansTotal}}</text>
            </view>
          </view>
          <image class="tx" :src="userInfo.headPortait" mode=""></image>
          <text class="name">{{userInfo.username}}</text>
          <image class="sex" v-if="userInfo.sex=='女'" src="../../static/女生.png" mode=""></image>
           <image class="sex" v-else src="../../static/男生.png" mode=""></image>
           <view class="address">
             <image class="address-icon" src="../../static/地点.png" mode=""></image>
             未知
           </view>
        </view>
      </view>
      <view class="all-box">
        <view class="history" @click="goHistory(userInfo.id)">
          <image class="img-item" src="../../static/浏览历史.png" mode=""></image>
          <text class="text-item">浏览历史</text>
        </view>
         <view class="history">
          <image @click="set(userInfo.id)" class="img-item" src="../../static/设置.png" mode=""></image>
          <text class="text-item">设置</text>
        </view>
         <view class="history">
          <image @click="shequ" class="img-item" src="../../static/set.png" mode=""></image>
          <text class="text-item">社区中心</text>
        </view>
         <view class="history">
          <image @click="set" class="img-item" src="../../static/消息.png" mode=""></image>
          <text class="text-item">心愿单</text>
        </view>
      </view>
      <view class="my-bottom">
        <!-- 顶部导航 -->
        <!-- 1、设置data-current属性用于：点击当前项时，通过点击事件swichNav中处理e.dataset.current取到点击的目标值。
        2、swiper组件的current组件用于控制当前显示哪一页
        3、swiper组件绑定change事件switchTab，通过e.detail.current拿到当前页 -->
        <view class="tab">
          <view :class="['tab-item' ,currenttab==0 ? 'active' : '']" data-current="0" @click="swichNav">游记</view>
          <view :class="['tab-item' ,currenttab==1 ? 'active' : '']" data-current="1" @click="swichNav">收藏</view>
      </view>
    <!-- <swiper :current="currenttab" @change="switchTab">
       <swiper-item> -->
         <view class="swiper-item" :hidden="currenttab==1">
           <article-list :list="mylist"></article-list>
         </view>
     <!--  </swiper-item>
       <swiper-item> -->
         <view class="swiper-item" :hidden="currenttab==0">
           <article-list :list="mycolllist"></article-list>
         </view>
    <!--   </swiper-item>
     </swiper> -->
      </view>
   </view>
    <view v-else>
      <view class="my-top">
         <view class="my-bg">
           <image src="../../static/swiper/2.png" mode=""></image>
         </view>
         <view class="my-avter">
           <image class="tx" src="../../static/c1.png" mode=""></image>
           <text class="name">还未登录！请先登录</text>
         </view>
       </view>
       <view class="tologin">
         <view class="loginitem" @click="tologin">
           去登录->
         </view>
       </view>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        isLogin:0,
        //三个状态
        currenttab:0,
        userInfo:{
          id:'',
        },
        FansTotal:0,
        Atttotal:0,
        queryObj:{
          pageNum:1,
          pageSize:5
        },
        //我的收藏列表
        mycolllist:[],
        mylist:[],
      };
    },
    onLoad(){
      this.userInfo.id=wx.getStorageSync('id')
      var id=wx.getStorageSync('id')
      // let res=wx.getStorageSync('token')
      // this.userInfo.id=res.id
      // var id=String(this.userInfo.open_id)
      this.getMyColList(id)
     this.getmyList(id)
     this.getUser(id)
     this.getAttTotal(id)
     this.getFansTotal(id)
    },
    methods:{
      //登录成功后顶部导航栏
      swichNav(e){
        console.log(e.target.dataset.current);
          this.currenttab=e.target.dataset.current
      },
      // switchTab(e){
      //   this.currenttab=e.detail.current
      // },
      //点击跳转到登录页面
      tologin(){
        uni.navigateTo({
          url:'/pages/login/login'
        })
      },
      //获取我的列表
     async getmyList(id){
       const {data:res}=await uni.$http.get('/articles/myArticles/'+id)
       // if(res.code!=200) return uni.$showMsg("请求失败！")
       this.mylist=res.data
       // console.log(res);
      },
      //获取我的收藏列表
     async getMyColList(id){
       console.log(id);
       // console.log(cc);
       const {data:res}=await uni.$http.get('/articles/myLikeArticles/'+id)
        // if(res.code!=200) return uni.$showMsg("请求失败!")
        console.log(res);
        this.mycolllist=res.data
        console.log(this.mycolllist);
      },
      async getUser(id){
        const {data:res}=await uni.$http.get('/user/'+id)
        console.log(res);
        this.userInfo=res.data
      },
     async getFansTotal(id){
        const {data:res}=await uni.$http.get('/user/userFans/'+ id )
        this.FansTotal=res.data.length
      },
     async getAttTotal(id){
         const{data:res}=await uni.$http.get('/user//likeUsers/'+id)
         this.Atttotal=res.data.length
         // console.log(res);
      },
      //跳转到粉丝列表
      goFansList(id){
        uni.navigateTo({
          url:'/subpkg/fanslist/fanslist?id='+id
        })
      },
      set(id){
        uni.navigateTo({
          url:'/subpkg/edituser/edituser?userid='+id
        })
      },
      //去看浏览历史
      goHistory(id){
        uni.navigateTo({
          url:'/subpkg/history/history?id='+id
        })
      }
  }
    }
</script>

<style lang="scss">
.my-container{
  .my-top{
    position: relative;
   .my-bg{
     border-radius: 10px;
     image{
       
       width: 100%;
     }
   }
   .my-avter{
     top: 150px;
     position: absolute;
     width: 100%;
     height: 90px;
     border-radius: 20px 20px 0 0;
     background-color: #aaa;
     opacity: 0.6;
     .set{
       width: 30px;
       height: 30px;
       position: absolute;
       top: 12px;
       left: 12px;
     }
     .box-list{
       display: flex;
       position: absolute;
       right: 50px;
       top: -35px;
     }
     .box{
      display: flex;
       flex-direction: column;
       align-items: center;
       margin-left: 40rpx;
     }
     .tx{
       position: absolute;
       left: 70rpx;
       // transform:translateX(-50%);
       top: -45px;
       width: 70px;
       height: 70px;
       border-radius: 50%;
     }
     .name{
       position: absolute;
       left: 60rpx;
       bottom: 40px;
       font-size: 38rpx;
       font-weight: 800;
     }
     .sex{
       position: absolute;
       left: 18rpx;
       bottom: 40px;
       width: 15px;
       height: 15px;
     }
     .address{
       position: absolute;
       left: 30rpx;
       bottom: 15px;
       padding: 5rpx 10rpx;
       .address-icon{
         margin-right: 10rpx;
         width: 25rpx;
         height: 25rpx;
       }
       font-size: 28rpx;
       border: 1px solid #707e60;
       border-radius: 40rpx;
     }
   } 
  }
  .tab{
    background-color: #2E2E2E;
    border-radius: 10px;
    display: flex;
    align-items: center;
    text-align: center;
    justify-content: space-around;
    // margin-top: -5px;
    padding: 10rpx 0;
    opacity: 0.9;
    .tab-item{
      width: 100rpx;
      height: 100%;
      padding: 20rpx 30rpx;
      font-size: 13px;
      color: #fff;
      border-radius: 40rpx;
      transition: all 1s;
    }
    .active{
      background-color: #fff;
      color: #2E2E2E;
    }
  }
   .tologin{
     .loginitem{
       height: 30px;
       width: 100px;
       margin-left: 50%;
       transform:translateX(-50%);
       // background-color: rgba(0, 0, 0, .2);
     }
   }
   // swiper{
   //   height: 2900px;
   // }
   .my-mid{
     // display: flex;
     position: absolute;
     width: 100%;
     top: 210px;
     // background-color: #cbe9c7;
     height: 130rpx;
     opacity: 0.8;
   }
   .all-box{
     margin-top: -15px;
     padding-bottom: 20rpx;
     padding-top: 20px;
     display: flex;
     width: 100%;
     height: 60px;
   }
   .history{
     // padding: 20rpx;
     width: 120rpx;
     height: 120rpx;
     margin-left: 30rpx;
     display: flex;
     
     flex-direction: column;
     align-items: center;
     border-radius: 40rpx;
     background-color: #fff;
     border: 1px solid #707e60;
   }
   // .history:hover{
   //         animation: drop 3s infinite;
   //         background-color: #707e60;
   //         @keyframes drop{ /*原图，放大一倍，再恢复到原图 */
   // 			0%{
   // 				transform:scale(1); /*transform：2D、3D转换,旋转、缩放、移动、倾斜*/
   // 			}
   // 			30%{
   // 				transform:scale(1.125);/*扩大到4倍*/
   // 			}
   // 			to{
   // 				transform: scale(1);
   // 			}
   // 		}
   //       }
   
   .img-item{
     width: 50rpx;
     height: 50rpx;
   }
   .text-item{
     font-size: 24rpx;
   }
}
</style>

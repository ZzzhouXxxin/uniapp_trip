<template>
  <view>
    <view class="city-box">
      <image src="../../static/向左箭头.png" class="comeback" @click="goindex" mode=""></image>
      <image class="city-img" :src="jdInfo.picture" mode=""></image>
      <view class="box-bottom">
        <view class="city-name">{{jdInfo.name}}<text class="rank">{{jdInfo.rank}}星级</text></view>
        <view class="address-box">
          <image class="icon-db" src="../../static/地点.png" mode=""></image>
          <text class="address">{{jdInfo.address}}</text>
        </view>
        <!-- <view class="instruction"> -->
          <text class="instruction">{{jdInfo.instruction}}</text>
        <!-- </view> -->
      </view>
    </view>
    <view class="list-box">
      <article-list :list="jdList"></article-list>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //获取得到的景点列表
        jdList:[],
        jdInfo:[]
      };
    },
    onLoad(e) {
      var id=e.id
      this.getJdList(id)
      this.getjdItem(id)
    },
    methods:{
      goindex(){
        uni.redirectTo({
          url:'/pages/index/index'
        })
      },
      async getjdItem(id){
        const {data:res}=await uni.$http.get('/scenic/'+id)
        // console.log(res);
        if(res.code!=200) return uni.$showMsg("请求失败！")
        this.jdInfo=res.data
      },
    async getJdList(id){
      console.log(id);
        const {data:res}=await uni.$http.get('/scenic/getArticles/'+id)
        if(res.code!=200) return uni.$showMsg("请求失败!")
        console.log(res);
        this.jdList=res.data
       
      }
    }
  }
</script>

<style lang="scss">
.city-box{
  position: relative;
  width: 100%;
  margin-bottom: 20rpx;
  border-bottom: 1px solid #707e60;
}
.city-img{
    // position: fixed;
    width: 100%;
    height: 400rpx;
    // overflow: hidden;
  }
  .box-bottom{
    position: absolute;
    top: 380rpx;
    z-index: 99;
    width: 100%;
    margin-top: -20rpx;
    border-radius: 30rpx;
    background-color: #fff;
    height: 200rpx;
  }
  .comeback{
    width: 40rpx;
    height: 40rpx;
    font-size: 35rpx;
    
    position: absolute;
    z-index: 99;
    top: 45rpx;
    left: 20rpx;
  }
  .icon-db{
    width: 30rpx;
    height: 30rpx;
  }
  .city-name{
    position: absolute;
    top: 15rpx;
    left: 20rpx;
    font-size: 44rpx;
  }
  .address-box{
    position: absolute;
    top: 70rpx;
    left: 15rpx;
    font-size: 38rpx;
    color: #707e60;
  }
  .instruction{
    position: absolute;
    top: 120rpx;
    left: 15rpx;
    font-size: 28rpx;
  }
  .address{
    font-size: 30rpx;
  }
  .list-box{
    position: absolute;
    top: 580rpx;
    width: 100%;
    margin-top: 20rpx;
  }
  .rank{
    font-size: 35rpx;
    margin-left: 10rpx;
    // position: absolute;
    // top: 1rpx;
    // left: 15rpx;
  }
</style>

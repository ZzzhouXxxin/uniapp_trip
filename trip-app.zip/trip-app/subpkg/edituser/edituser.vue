<template>
  <view class="edit-box">
    <view class="avatar">
      <image class="imag" :src="userInfo.headPortait" mode=""></image>
    </view>
    <jh-input-alert title='输入框标题' placeholder='请输入' maxlength='10' bind:cancel='cancel' bind:confirm='confirm'
    	v-if="showusername" />

    <view class="nickname">
      <view class="nickname-left">
        昵称
      </view>
      <view class="nickname-right" >
        {{userInfo.username}}
        <image class="icon"  src="../../static/right-jt.png" mode=""></image>
      </view>
    </view>
    <view class="gander">
      <view class="gander-left">
        性别
      </view>
      <view class="gander-right">
        {{userInfo.sex}}
        <image class="icon" src="../../static/right-jt.png" mode=""></image>
      </view>
    </view>
    <view class="kefu">
      关于客服
    </view>
    <view class="exit">
      <button @click="exit" type="warn" class="exit-btn">退出</button>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //改变昵称对话框
        showusername:false,
        userInfo:{
        }
      };
    },
    onLoad(e) {
       let res=wx.getStorageSync('token')
      // console.log(e.userid);
      this.getUser(e.userid)
    },
    methods:{
    //退出
    exit(){
      this.userInfo='',
      wx.setStorageSync('token','')
      wx.setStorageSync('username','')
      wx.setStorageSync('avatarUrl','')
      wx.setStorageSync('id','')
     wx.redirectTo({
        url:'/pages/my/my'
      })
    },
    async getUser(id){
      const {data:res}=await uni.$http.get('/user/'+id)
      if(res.code!=200) return uni.$showMsg('获取用户信息失败！')
      console.log(res.data);
      this.userInfo=res.data
    }
    }
  }
</script>

<style lang="scss">
.edit-box{
  display: flex;
  flex-direction: column;
  }
  .avatar{
    height: 350rpx;
    margin-top: 20px;
  }
  .imag{
    width: 180rpx;
    height: 180rpx;
    border-radius: 50%;
    margin-left: 50%;
    transform: translateX(-50%);
  }
  .nickname ,
  .gander,
  .kefu{
    display: flex;
    height: 80rpx;
    border-bottom: 1px solid #d5e3d4;
    justify-content: space-between;
    line-height: 80rpx;
    padding: 0 10rpx;
  }
  .icon{
   width: 30rpx;
   height: 30rpx;
   }
  .exit{
    .exit-btn{
      width: 100%;
      margin-top: 30px;
    }
}
</style>

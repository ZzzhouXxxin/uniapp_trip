<template>
  <view>
    <!-- 顶部自定义导航栏 -->
    <view class="top-box" >
      <view class="top-nav" :style="{height:stateHeight+'px'}">
        
      </view>
       <view class="author">
         <image @click="goback" class="arrow" src="../../static/向左箭头.png" mode=""></image>
       </view>
    </view>
    <view class="allaticle">
      <view :class="['aticle-attention' ,currentpage==0 ? 'active' : '']" data-current="0" @click="switchnav">
        关注
      </view>
      <view :class="['aticle-all' ,currentpage==1 ? 'active' : '']" data-current="1" @click="switchnav">
        粉丝
      </view>
    </view>
    <view class="fanslist" :hidden="currentpage==0">
     <block v-for="(item,i) in fanslist" :key="i">
       <view class="fans-item" @click="goUserhome(item.id)">
         <image class="fans-img" :src="item.headPortait" mode=""></image>
         <text class="fans-text">{{item.username}}</text>
         <view v-if="item.isCollection==0" class="guanzhu">
           关注
         </view>
         <view class="yiguanzhu" v-else >
           已关注
         </view>
       </view>
     </block>
    </view>
    <view class="attation" :hidden="currentpage==1">
    <block v-for="(item,i) in guanlist" :key="i">
      <view class="fans-item" @click="goUserhome(item.id)">
        <image class="fans-img" :src="item.headPortait" mode=""></image>
        <text class="fans-text">{{item.username}}</text>
        <view v-if="this.isCollection==0" class="guanzhu">
          关注
        </view>
        <view v-else  class="yiguanzhu">
          已关注
        </view>
      </view>
    </block>
    </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        currentpage:1,
          fanslist:[],
          guanlist:[],
          stateHeight:0,
          navHeight:0,
          username:'',
          total:0,
          userId:''
      };
    },
    onLoad(e) {
      // this.username=wx.getStorageSync('username')
      this.userId=wx.getStorageSync('id')
      this.getFansList(e.id)
      this.getGuanList(e.id)
      this.fn()
    },
    methods:{
      fn() {
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;	//  获取胶囊高度
          let top = 0;
      	wx.getSystemInfo({
            success(res) {
              console.log("状态栏：" + res.statusBarHeight)
              stateHeight = res.statusBarHeight;
            }
          })
           this.navHeight=navHeight 
            this.stateHeight=stateHeight		
              //  状态栏高度
      },
      switchnav(e){
        // console.log(e.currentTarget.dataset.current);
        this.currentpage=e.currentTarget.dataset.current;
      },
      goback(){
        var pages = getCurrentPages(); //当前页面
        
        var beforePage = pages[pages.length - 2]; //前一页
        
        wx.navigateBack({
        
        success: function () {
        
        beforePage.onShow(); // 执行前一个页面的onLoad方法
        
        }
        
        });
     
       // uni.redirectTo({
       //   url:'/pages/my/my'
       // })
      },
      //关注用户
      async atuser(id){
       if(this.isCollection==0){
         this.isCollection=1
         const {data:res}=await uni.$http.post('/user/concernOtherUser',{
               toUserId:id,
               userId:this.userId,
               isCollection:1
         })
         if(res.code!=200) return uni.$showMsg('关注失败!')
         uni.$showMsg("关注成功！")
         console.log(res);
       }else{
         this.isCollection=0
         const {data:res}=await uni.$http.post('/user/concernOtherUser',{
               toUserId:id,
               userId:this.userId,
               isCollection:0
         })
         if(res.code!=200) return uni.$showMsg('关注失败!')
         uni.$showMsg("关注成功！")
         console.log(res);
       }
      },
      //去用户的首页
      goUserhome(id){
        uni.navigateTo({
          url:'/subpkg/user-home/user-home?id='+id
        })
      },
      //获取粉丝列表
      async getFansList(id){
        console.log(id);
        const {data:res}=await uni.$http.get('/user/userFans/'+ id )
        if(res.code!=200) return uni.$showMsg("获取粉丝列表失败！")
        console.log(res.data);
        this.fanslist=res.data
        this.total=res.data.length
      },
      async getGuanList(id){
        const{data:res}=await uni.$http.get('/user//likeUsers/'+id)
        console.log(res);
        if(res.code!=200) return uni.$showMsg("获取关注列表失败！")
        this.guanlist=res.data
      }
    }
  }
</script>

<style lang="scss">
.top-box{
      position: sticky;
      top:0;
      background-color:#fff;
      z-index: 9999;
      padding-bottom: 20rpx;
    }
.author{
      margin-top: 10rpx;
      display: flex;
      justify-content: flex-start;
      .arrow{
      margin-left: 10px;
      // margin-top: 10px;
      width: 60rpx;
      height: 60rpx;
      }
    }
    .guanzhu{
      padding: 0 30rpx;
      background-color: #b02e28;
      color: #fff;
      font-size: 32rpx;
       border-radius: 20rpx;
       float: right;
      margin-right: 20px;
    }
    .yiguanzhu{
      margin-right: 10px;
      padding: 0 20rpx;
      border-radius: 20rpx;
      background-color: #2E2E2E;
      color: #fff;
      font-size: 32rpx;
      float: right;
      margin-right: 20px;
    }
  .fanslist{
    margin-left: 20rpx;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
  }
  .fans-item{
    height: 100rpx;
    padding: 15rpx 0;
    align-items: center;
    // height: 120rpx;
    // display: flex;
    line-height: 100rpx;
   vertical-align: middle;
    //border-bottom: 1px solid #aaa;
  }
  .fans-img{
    float: left;
    margin-right: 15px;
    width: 100rpx;
    height: 100rpx;
    border-radius: 50%;
  }
  .fans-text{
    display: block;
    float: left;
    font-size: 34rpx;
  }
  .allaticle{
    display: flex;
    justify-content: center;
    margin-top: 7px;
    .aticle-attention{
      font-size: 12px;
      padding: 5px 15px;
      margin-right: 10px;
      color: #aaa;
    }
    .aticle-all{
      font-size: 12px;
      padding: 5px 15px;
      margin-left: 10px;
      color: #aaa;
    }
    .active{
       // background-color: #d5ddc1;
       color: #707e60;
       font-size: 16px;
       font-weight: bold;
    }
  }
</style>

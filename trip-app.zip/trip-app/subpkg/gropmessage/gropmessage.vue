<template>
  <view>
    <view class="top-box">
      <view class="top-nav" :style="{height:stateHeight+'px'}">  
      </view>
      <view class="headbox">
        <image @click="goback" class="arrow" src="../../static/向左箭头 (1).png" mode=""></image>
          <view class="grop">
            <text class="gropname">今天去哪玩呢</text>
            <text class="groppeople">4人在线</text>
          </view>
      </view>
     </view> 
      <send></send>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        stateHeight:''
      };
    },
    onLoad() {
      this.fn()
    },
    methods:{
      fn() {
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;
          let top = 0;
       wx.getSystemInfo({
            success(res) {
              // console.log("状态栏：" + res.statusBarHeight)
              stateHeight = res.statusBarHeight;
            }
          })
           this.navHeight=navHeight
            this.stateHeight=stateHeight		
      },
    }
  }
</script>

<style lang="scss">
.top-box{
     position: sticky;
     top:0;
     background-color: #fff;
     z-index: 9999;
   }
   .headbox{
     height: 120rpx;
     align-items: center;
     display: flex;
     align-items: center;
     // justify-content: ;
   }
   .arrow{
   margin-left: 10px;
   // margin-top: 10px;
   width: 40rpx;
   height: 40rpx;
   margin-right: 10rpx;
   }
   .grop{
     margin-left: 50%;
     transform: translateX(-120%);
     display: flex;
     flex-direction: column;
     align-items: center;
   }
   .gropname{
     font-weight: 800;
     color: chocolate;
   }
   .groppeople{
     font-size: 24rpx;
   }
</style>

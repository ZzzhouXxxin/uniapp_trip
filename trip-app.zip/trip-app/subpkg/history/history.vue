<template>
  <view>
   <!-- 顶部自定义导航栏 -->
   <view class="top-box">
     <view class="top-nav" :style="{height:stateHeight+'px'}">
       
     </view>
    <view class="history-item">
      <image @click="goback" class="arrow" src="../../static/向左箭头.png" mode=""></image>
        <text class="history-text">浏览历史</text>
    </view>
   </view>
   <view class="history-list">
     <article-list :list="historylist"></article-list>
   </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //状态栏高度
        stateHeight:0,
        historylist:[]
      };
    },
    onLoad(e) {
      this.fn()
      console.log(e);
      this.getHistoryList()
    },
    methods:{
      //  获取状态栏信息
      fn() {
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;	//  获取胶囊高度
          let top = 0;
      	wx.getSystemInfo({
            success(res) {
              console.log("状态栏：" + res.statusBarHeight)
              stateHeight = res.statusBarHeight;
            }
          })
           this.navHeight=navHeight
            this.stateHeight=stateHeight		
      },
      async getHistoryList(){
        const {data:res}=await uni.$http.get('/articles/getBrowse')
        if(res.code!=200) return uni.$showMsg("请求失败！")
        console.log(res);
        this.historylist=res.data
      },
      goback(){
        uni.redirectTo({
          url:'/pages/my/my'
        })
      }
    }
  }
</script>

<style lang="scss">
.top-box{
      position: sticky;
      top:0;
      background-color:#fff;
      z-index: 9999;
    }
    .history-item{
      margin-top: 10px;
      display: flex;
      justify-content: start;
      vertical-align: top;
      align-items: center;
    }
    .arrow{
      margin-left: 10px;
      // margin-top: 10px;
      width: 60rpx;
      height: 60rpx;
    }
    .history-text{
      // margin-top: 5px;
      font-size: 32rpx;
      margin-left: 70px;
      // text-align: center;
    }
</style>

<template>
  <view>
    <view class="top-box">
      <view class="top-nav" :style="{height:stateHeight+'px'}">  
      </view>
      <view class="author">
        <image @click="goback" class="arrow" src="../../static/向左箭头 (1).png" mode=""></image>
          <view class="userInfo">
            <image class="headimg" :src="userInfo.headPortait" mode=""></image>
            <text class="username">{{userInfo.username}}</text>
          </view>
      </view>
     </view> 
     
      <send></send>
     <view class="message-box">
       <view class="flex">
         <input type="text" class="sendmessage" placeholder="聊聊天吧!" @input="sendmessage">
         <view class="icon-box">
            <image class="sendicon" src="../../static/tabs_icon/input-1.png" mode=""></image>
         </view>
       </view>
     </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        stateHeight:'',
        userInfo:[],
        sotk:{},
        socketOpen: false,
        wsbasePath:"wss://eg2ax8.natappfree.cc:9000/chat/"
      };
    },
    onLoad(e) {
      this.fn()
      this.getUser(e.id)
      this.conect()
    },
    methods:{
      //获取连接
      conect(){
       var _this = this;
            //创建websocket
            //正式地址使用wss
            var id=wx.getStorageSync('id')
            this.sotk = wx.connectSocket({
                url: this.wsbasePath+id,
                success: res => {
                    console.info('创建连接成功');
                    console.log(res);
                    //socketTaskId: 22
                    // console.info(res);
                },
                fail: err => {
                  console.log('出现错误啦！！' + err);
                  wx.showToast({
                    title: '网络异常！',
                  })
                }
            });
            console.log("sotk" + this.sotk);
              //事件监听
            this.webSokcketMethods();
        },
        //监听指令
          webSokcketMethods(e){
            // let that = this;
            this.sotk.onOpen(res => {
              this.socketOpen = true;
              console.log('监听 WebSocket 连接打开事件。', res);
            })
            this.sotk.onClose(onClose => {
              console.log('监听 WebSocket 连接关闭事件。', onClose)
              this.socketOpen = false;
            })
            this.sotk.onError(onError => {
              console.log('监听 WebSocket 错误。错误信息', onError)
              this.socketOpen = false
            })
        
            this.sotk.onMessage(onMessage => {
              var data = JSON.parse(onMessage.data);
              console.log('监听WebSocket接受到服务器的消息事件。服务器返回的消息',data);
             
            })
           
          },
            //发送消息
            sendSocketMessage(msg) {
              // let that = this;
              if (this.socketOpen){
                console.log('通过 WebSocket 连接发送数据', JSON.stringify(msg))
                this.sotk.send({
                  data: JSON.stringify(msg)
                }, function (res) {
                  console.log('已发送', res)
                })
              }
              
            },
           //关闭连接
            closeWebsocket(str){
              if (this.socketOpen) {
                this.sotk.close(
                  {
                    code: "1000",
                    reason: str,
                    success: function () {
                      console.log("成功关闭websocket连接");
                    }
                  }
                )
              }
            },
      //获取连接
  //     conectWebSocket(){
  //       console.log(this.userInfo.username);
        
  //         var websocket = null
  // //判断当前浏览器是否支持WebSocket
  //         if ('WebSocket' in window) {
  //             websocket = new WebSocket("ws://10.4.4.83:20713/websocket/" + this.userInfo.username);
  //         } else {
  //             alert('Not support websocket')
  //         }
  //         //连接发生错误的回调方法
  //         websocket.onerror = function() {
  //             setMessageInnerHTML("error");
  //         };
  //         //连接成功建立的回调方法
  //         websocket.onopen = function(event) {
  //             setMessageInnerHTML("Loc MSG: 成功建立连接");
  //         }
  //         //接收到消息的回调方法
  //         websocket.onmessage = function(event) {
  //             setMessageInnerHTML(event.data);
  //         }
  //         //连接关闭的回调方法
  //         websocket.onclose = function() {
  //             setMessageInnerHTML("Loc MSG:关闭连接");
  //         }
  //         //监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
  //         window.onbeforeunload = function() {
  //             websocket.close();
  //         }
  //     },
      
      fn() {
          let stateHeight = 0;		//  接收状态栏高度
          let navHeight = wx.getMenuButtonBoundingClientRect().height;
          let top = 0;
       wx.getSystemInfo({
            success(res) {
              // console.log("状态栏：" + res.statusBarHeight)
              stateHeight = res.statusBarHeight;
            }
          })
           this.navHeight=navHeight
            this.stateHeight=stateHeight		
      },
      async getUser(id){
        const {data:res}=await uni.$http.get('/user/'+id)
        console.log(res);
        this.userInfo=res.data
      },
      goback(){
     var pages = getCurrentPages(); //当前页面
     
     var beforePage = pages[pages.length - 2]; //前一页
     
     wx.navigateBack({
    
     });

      }
    }
  }
</script>

<style lang="scss">
.top-box{
     position: sticky;
     top:0;
     background-color: #fff;
     z-index: 9999;
   }
   .author{
     height: 120rpx;
     align-items: center;
     display: flex;
     // justify-content: ;
   }
   .arrow{
   margin-left: 10px;
   // margin-top: 10px;
   width: 40rpx;
   height: 40rpx;
   margin-right: 10rpx;
   }
   .userInfo{
     margin-left: 50%;
     transform: translateX(-120%);
     display: flex;
     flex-direction: column;
     align-items: center;
   }
   .headimg{
     width: 80rpx;
     height: 80rpx;
     border-radius: 50%;
   }
   .username{
     font-size: 26rpx;
   }
   .message-box{
     width: 100%;
     position: fixed;
     bottom: 0;
     padding-bottom: 20px;
     background-color: #d5e3d4;
   }
   .flex{
     text-align: center;
     align-items: center;
     justify-content: space-around;
     display: flex;
   }
   .sendmessage{
     width: 80%;
     padding: 10rpx;
     border: 1px solid #fff;
     border-radius: 40rpx;
   }
   .icon-box{
     // margin-left: 20rpx;
     width: 60rpx;
     height: 60rpx;
     background-color: #d5e3d4;
     border-radius: 20rpx;
     border: 1px solid #fff;
   }
   .sendicon{
     width: 40rpx;
     height: 40rpx;
     padding-top: 10rpx;
     padding-right: 10rpx;
   }
   .icon-box:hover{
     background-color: #fff;
     border: 1px solid #d5e3d4;
     animation: drop 2s infinite;
        @keyframes drop{ /*原图，放大一倍，再恢复到原图 */
     0%{
     	transform:scale(1); /*transform：2D、3D转换,旋转、缩放、移动、倾斜*/
     }
     30%{
     	transform:scale(1.125);/*扩大到4倍*/
     }
     to{
     	transform: scale(1);
     }
   }
   }
</style>

<template>
  <view class="detail">
    <view class="top-box">
      <view class="top-nav" :style="{height:stateHeight+'px'}">  
      </view>
      <view class="author">
        <image @click="goback" class="arrow" src="../../static/向左箭头 (1).png" mode=""></image>
          <image @click="goUserHome(userInfo.id)" class="headimg" :src="userInfo.headPortait" mode=""></image>
          <text class="username">{{userInfo.username}}</text>
          <image v-if="isAuthor==1" @click="remove(article.id)" class="delete" src="../../static/删除.png" mode=""></image>
      </view>
     </view> 
    <swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" :circular="true">
      <swiper-item v-for="(item, i) in article.pictures" :key="i">
        <image class="pic" :src="item"></image>
      </swiper-item>
    </swiper>
    <view class="title">{{article.title}}</view>
    <view class="content">
      {{article.content}}
    </view>
    <view class="putdata">
      {{article.createDate}}
    </view>
    <view>
    </view>
    <view class="bottom">
       <view class="total">共{{article.commentCount}}条评论</view>
      </view>
       <my-comment :list1="commentlist" :getCommentList="getCommentList" :article="article"></my-comment>
     <!-- //固定的底部导航栏 -->
     <!-- //固定的底部导航栏 -->
      <view class="bottom-box">
       <!-- <view class="bottom-right"> -->
         <view class="icon">
           <image v-if="!article_like_status" @click="tolike" class="img-like" src="../../static/点赞.png" mode=""></image>
           <image v-else @click="tolike" src="../../static/点赞 (1).png" class="img-like" mode=""></image>
           <view class="text">{{article_like_count}}</view>
         </view>
         <view class="icon">
           <image v-if="isCollection==0" @click="tocollect(article.id)" class="img-sc" src="../../static/收藏.png" mode=""></image> 
           <image v-else @click="tocollect(article.id)" class="img-sc" src="../../static/收藏 (2).png" mode=""></image>
         </view>
         <view class="icon">
           <image class="img-pl" src="../../static/评论.png" mode=""></image>
           <view class="text">{{article.commentCounts}}</view>
         </view>
          <view class="icon">
            <button class="btn" plain="true" open-type="share"><image class="img-pl" src="../../static/3.1转发 (1).png" mode=""></image></button>
         </view>
       <!-- </view> -->
     </view>
   </view>
   </view>
</template>

<script>
  export default {
    data() {
      return {
        //文章
        article:'',
        //一级评论列表
        userInfo:[],
        commentlist:[],
        isCollection:0,
        article_like_count:'',//文章点赞数
        article_like_status:false,
        authorId:'',
        stateHeight:0,
        isAuthor:0,
        showModalStatus:false
      };
    },
    onShareAppMessage(res) {
        if (res.from === 'button') {// 来自页面内分享按钮
            console.log(res.target)
        }
        return {
            title: 'title', //分享的名称
            path: '/pages/hfdt/gztjh',
            mpId:'wx6bf107b87c455b99' //此处配置微信小程序的AppId
        }
    },
    //分享到朋友圈
    onShareTimeline(res) {
        return {
            title: '胶南街道召开“红帆支部”观摩学习暨工作推进会',
            type: 0,
            summary: "",
        }
    },
    onLoad(e) {
      console.log(11);
      const item = JSON.parse(decodeURIComponent(e.item));
      // console.log(item);
      this.fn()
      this.authorId = wx.getStorageSync('id')
      if(this.authorId==item.userVo.id){
        this.isAuthor=1
      }
      // var id = Number(e.id)
      this.getArticleList(item.id)
      this.getCommentList(item.id)
      //获取用户信息
      this.getUser(item.userVo.id)
    },
    methods:{
      //  获取状态栏信息
       fn() {
           let stateHeight = 0;		//  接收状态栏高度
           let navHeight = wx.getMenuButtonBoundingClientRect().height;
           let top = 0;
        wx.getSystemInfo({
             success(res) {
               console.log("状态栏：" + res.statusBarHeight)
               stateHeight = res.statusBarHeight;
             }
           })
            this.navHeight=navHeight
             this.stateHeight=stateHeight		
       },
     async getArticleList(articleId){
        const {data:res}=await uni.$http.get('/articles/view/'+articleId)
        // if(res.code!=200) return uni.$showMsg('请求失败！')
        // console.log(res);
        this.article=res.data
        console.log(this.article);
      this.article_like_count=res.data.article_like_count
      this.isCollection=res.data.isCollection
      },
      //获取用户信息
      async getUser(id){
        const {data:res}=await uni.$http.get('/user/'+id)
        console.log(res);
        this.userInfo=res.data
      },
      //获取评论列表
     async getCommentList(id){
       const{data:res}=await uni.$http.get('/comment/'+id)
       console.log(res.data);
       this.commentlist=res.data
      this.commentlist=this.commentlist.reverse()
      },
      //点赞文章
        async tolike(){
          if(wx.getStorageSync('username')==''||wx.getStorageSync('id')=='') return uni.$showMsg('您还未登录，请先登录！')
          if(this.article_like_count==0){
            this.article_like_count==1
            this.article_like_status=true
            const {data:res}=await uni.$http.post('/articles/addLike',{
              articleId:this.articleId,
              userId:this.authorId
            })
            if(res.code!=200) return uni.$showMsg('点赞失败！')
           
          }else{
            this.article_like_count++
             this.article_like_status=true
            const {data:res}=await uni.$http.post('/articles/addLike',{
              articleId:this.articleId,
              userId:this.authorId
            })
            if(res.code!=200) return uni.$showMsg('点赞失败！')
           
          }
        },
        //收藏文章
      async  tocollect(id){
        if(wx.getStorageSync('username')==''||wx.getStorageSync('id')=='') return uni.$showMsg('您还未登录，请先登录！')
        if(this.isCollection==0){
          this.isCollection=1
          const {data:res}=await uni.$http.post('/articles/collectArticle',{
           articleId:id,
           authorId:this.authorId,
           isCollection:1
          })  
          if(res.code!=200) return uni.$showMsg("收藏失败!")
             uni.$showMsg("收藏成功!")
          console.log(res);
        }else{
          this.isCollection=0
          const {data:res}=await uni.$http.post('/articles/collectArticle',{
           articleId:id,
           authorId:this.authorId,
           isCollection:0
          })  
          if(res.code!=200) return uni.$showMsg("收藏失败!")
          uni.$showMsg("取消收藏成功!")
          console.log(res);
        }
        },
      edit(item){
        uni.navigateTo({
          url:'/subpkg/my-edit/my-edit?article='+item
        })
      },
      goback(){
       var pages = getCurrentPages(); //当前页面
       
       var beforePage = pages[pages.length - 2]; //前一页
       
       wx.navigateBack({
       
       // success: function () {
       
       // beforePage.onShow(); // 执行前一个页面的onLoad方法
       
       // }
       
       });
      },
      goUserHome(id){
        console.log(id);
        if(id==wx.getStorageSync('id')){
          uni.navigateTo({
            url:'/pages/my/my'
          })
        }else{
          uni.navigateTo({
            url:'/subpkg/user-home/user-home?id='+id
          })
        }
      },
      remove(id){
       wx.showModal({
             title: '提示',
             content: '确定要删除吗？',
             success: function (sm) {
               if (sm.confirm) {
                   // 用户点击了确定 可以调用删除方法了
                   const res=uni.request({
                     url:'http://eg2ax8.natappfree.cc/articles/deleteArticle',
                     method:'DELETE',
                     data:{
                       articleId:id,
                       userId:wx.getStorageSync('id')
                     },
                     header:{ Authorization:wx.getStorageSync('token') },
                         success: (res) => {
                             console.log(res.data);
                             if(res.data.code!=200) return uni.$showMsg("删除失败！")
                             uni.$showMsg("删除成功！")
                             let pages = getCurrentPages();                       //   获取当前小程序打开页面信息列表 .
                             let prevPage = pages[pages.length - 2];         //    获取要返回页面信息， 如要返回下标是2的页面
                             prevPage=wx.navigateBack({            
                                   delta: 2,         
                             })
                             // setTimeout(uni.redirectTo({
                             //   url:'/pages//index/index'
                             // }),2000)
                         }
                   })
                 } else if (sm.cancel) {
                   console.log('用户点击取消')
                 }
               }
             }) 
         }
    }
  }
</script>

<style lang="scss">
  .detail{
    background-color:#fff ;
    width: 100%;
    height: 1000px;
   swiper{
     height: 800rpx;
     width: 100%;    
     margin-bottom: 30rpx;
     .pic{
       // margin-top: 30rpx;
       width: 100%;
       height: 100%;
     }
   } 
   .author{
       margin-top: 10rpx;
       display: flex;
       padding-bottom: 10rpx;
       align-items: center;
       justify-content: flex-start;
       .arrow{
       margin-left: 10px;
       // margin-top: 10px;
       width: 40rpx;
       height: 40rpx;
       margin-right: 10rpx;
       }
       .headimg{
         width: 70rpx;
         height: 70rpx;
         border-radius: 50%;
       }
       .username{
         margin-left: 20rpx;
         font-size: 30rpx;
       }
       .delete{
         width: 40rpx;
         height: 40rpx;
         margin-left: 20px;
       }
       }
   .top-box{
     position: sticky;
     top:0;
     background-color: #fff;
     z-index: 9999;
   }
   .title{
     width: 100%;
     padding-left: 10rpx;
     padding-bottom: 20rpx;
     border-bottom: 1px solid #cad7c5;
     font-weight: 600;
   }
   .content{
     // width: 100%;
     padding: 10rpx;
     // text{
     //   padding-right: 10rpx;
     // }
     font-size: 34rpx
   }
   .putdata{
     margin-top: 50rpx;
     font-size: 30rpx;
     color: #cad7c5;
   }
  .bottom{
    margin-top: 50rpx;
    // border-top: 1px solid #cad7c5;
    .total{
      font-size: 34rpx;
      margin-bottom: 10rpx;
    }
     // -moz-box-shadow:0 0 10px #faf6df;
     // -webkit-box-shadow:0 0 10px #faf6df;
     // box-shadow:0 0 10px #faf6df;
  }

    .bottom-box{
      background-color: #fff;
      width: 100%;
      height: 160rpx;
      // background-color:#faf6df;
      position: fixed;
      display: flex;
      justify-content: space-around;
      bottom: 0;
      border-top: 1px solid #d5e3d4;
      }
      .icon{
        display: flex;
        align-items: center;
        justify-content: space-between;
        
      }
      .btn{
        background-color: #fff;
        outline: none;
        margin-top: 10rpx;
      }
      button[plain]{ border:0 }
      .text{
        font-size: 26rpx;
      }
      .img-sc{
        width: 60rpx;
        height: 60rpx;
      }
      .img-like{
        width: 60rpx;
        height: 60rpx;
      }
      .img-pl{
        width: 60rpx;
        height: 60rpx;
      }
}
</style>

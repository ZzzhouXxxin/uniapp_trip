<template>
  <view>
   <view class="search-box">
     <!-- 使用 uni-ui 提供的搜索组件 -->
     <uni-search-bar @input="input" :radius="100" cancelButton="none"></uni-search-bar>
   </view>
   <view class="sugg-list" v-if="searchlist.length!==0">
     <view class="sugg-item" v-for="(item, i) in searchlist" :key="i" @click="gotoDetail(word)">
       <view class="goods-name">{{item.title}}</view>
       <uni-icons type="arrowright" size="16"></uni-icons>
     </view>
   </view>
   <!-- 搜索历史 -->
   <view class="history-box" v-else>
     <!-- 标题区域 -->
     <view class="history-title">
       <text>搜索历史</text>
       <uni-icons type="trash" size="17" @click="remove"></uni-icons>
     </view>
     <!-- 列表区域 -->
     <view class="history-list">
       <uni-tag :text="item" v-for="(item, i) in historyList" :key="i" @click="goarticlelist(item)"></uni-tag>
     </view>
   </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        timer:null,
        word:'',
        searchlist:[],
         // 搜索关键词的历史记录
        historyList: ['滕王阁']
      };
    },
    // onLoad() {
    //    this.historyList = JSON.parse(uni.getStorageSync('word') || '[]')
    // },
    // computed: {
    //   historys() {
    //     // 注意：由于数组是引用类型，所以不要直接基于原数组调用 reverse 方法，以免修改原数组中元素的顺序
    //     // 而是应该新建一个内存无关的数组，再进行 reverse 反转
    //     return [...this.historyList].reverse()
    //   }
    // },
    methods:{
      //获取输入框中输入的值
      input(e){
        clearTimeout(this.timer)
        // 重新启动一个延时器，并把 timerId 赋值给 this.timer
        this.timer = setTimeout(() => {
          // 如果 500 毫秒内，没有触发新的输入事件，则为搜索关键词赋值
          this.word = e
          this.getSearchList()
          // console.log(this.word)
        }, 500)
        console.log(e);
      },
     async getSearchList(){
        if(this.word==''){
          this.searchlist=[]
        }
        const {data:res}=await uni.$http.get('/articles/search/'+this.word)
        console.log(res);
        // if(res.code!=200) return uni.$showMsg('获取失败！')
        this.searchlist=res.data
        this.seveSearchHistory()
      },
      seveSearchHistory(){
        this.historyList.push(this.word)
        this.historyList=this.historyList.reverse()
        // 1. 将 Array 数组转化为 Set 对象
        // const set = new Set(this.historyList)
        // console.log(set);
        // 2. 调用 Set 对象的 delete 方法，移除对应的元素
        // set.delete(this.kw)
        // 3. 调用 Set 对象的 add 方法，向 Set 中添加元素
        // set.add(this.kw)
        // 4. 将 Set 对象转化为 Array 数组
        // this.historyList = Array.from(set)
        //  uni.setStorageSync('word', JSON.stringify(this.historyList))
      },
      remove(){
          // 清空 data 中保存的搜索历史
          this.historyList = []
          // 清空本地存储中记录的搜索历史
          uni.setStorageSync('word', '[]')
      },
      //去文章详情
      gotoDetail(word){
        console.log(11);
        uni.navigateTo({
          url:'/subpkg/search_list/search_list?word='+word
        })
      },
      //跳转到文章列表
      goarticlelist(word){
        uni.navigateTo({
          url:'/subpkg/search_list/search_list?word='+word
        })
      }
    }
  }
</script>

<style lang="scss">
.uni-searchbar {
  display: flex;
  flex-direction: row;
  position: relative;
  padding: 16rpx;
  background-color: #d5e3d4;
}
.search-box {
  position: sticky;
  top: 0;
  z-index: 999;
}
.sugg-list {
  padding: 0 5px;

  .sugg-item {
    font-size: 12px;
    padding: 13px 0;
    border-bottom: 1px solid #efefef;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .goods-name {
      // 文字不允许换行（单行文本）
      white-space: nowrap;
      // 溢出部分隐藏
      overflow: hidden;
      // 文本溢出后，使用 ... 代替
      text-overflow: ellipsis;
      margin-right: 3px;
    }
  }
}
.history-box {
  padding: 0 5px;

  .history-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 40px;
    font-size: 13px;
    border-bottom: 1px solid #efefef;
  }

  .history-list {
    display: flex;
    flex-wrap: wrap;

    .uni-tag {
      margin-top: 5px;
      margin-right: 5px;
    }
  }
}
</style>

<template>
  <view>
  
    <article-list :list="searchlist"></article-list>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        searchlist:[]
      };
    },
    onLoad(e) {
      console.log(e.word);
      this.getSearchList(e.word)
    },
    methods:{
      async getSearchList(word){
         if(this.word==''){
           this.searchlist=[]
         }
         const {data:res}=await uni.$http.get('/articles/search/'+word)
         console.log(res);
         // if(res.code!=200) return uni.$showMsg('获取失败！')
         this.searchlist=res.data
       },
    }
  }
</script>

<style lang="scss">
.uni-searchbar {
  display: flex;
  flex-direction: row;
  position: relative;
  padding: 16rpx;
  background-color: #d5e3d4;
}
.search-box {
  position: sticky;
  top: 0;
  z-index: 999;
}
</style>

<template>
  <view>
   <view>
     <view class="my-top">
        <view class="my-bg">
          <image src="../../static/2.jpg" mode=""></image>
        </view>
         <image @click="goback" class="arrow" src="../../static/向左箭头.png" mode=""></image>
        <view class="my-avter">
          <view class="box-list">
            <view class="box" @click="goFansList(userInfo.id)">
              <text class="wenzi">关注</text>
              <text class="number">{{Atttotal}}</text>
            </view>
            <view class="box" @click="goFansList(userInfo.id)">
              <text class="wenzi">粉丝</text>
              <text class="number">{{Fanstotal}}</text>
            </view>
          </view>
          <image class="tx" :src="userInfo.headPortait" mode=""></image>
          <text class="name">{{userInfo.username}}</text>
          <image class="sex" v-if="userInfo.sex=='女'" src="../../static/女生.png" mode=""></image>
           <image class="sex" v-else src="../../static/男性.png" mode=""></image>
           <view class="address">
             <image class="address-icon" src="../../static/地点.png" mode=""></image>
             {{userInfo.address}}
           </view>
           <view class="fuction">
             <view class="message" @click="gosend(userInfo.id)">
               发消息
             </view>
             <view v-if="isCollection==0" @click="atuser(userInfo.id)" class="guanzhu">
               关注
             </view>
             <view v-else @click="atuser(userInfo.id)" class="yiguanzhu">
               已关注
             </view>
           </view>
        </view>
      </view>
      <view class="my-bottom">
        <!-- 顶部导航 -->
        <!-- 1、设置data-current属性用于：点击当前项时，通过点击事件swichNav中处理e.dataset.current取到点击的目标值。
        2、swiper组件的current组件用于控制当前显示哪一页
        3、swiper组件绑定change事件switchTab，通过e.detail.current拿到当前页 -->
        <view class="tab">
          <view :class="['tab-item' ,currenttab==0 ? 'active' : '']" data-current="0" @click="swichNav">游记</view>
          <view :class="['tab-item' ,currenttab==1 ? 'active' : '']" data-current="1" @click="swichNav">收藏</view>
      </view>
         <view class="swiper-item" :hidden="currenttab==1">
           <article-list :list="helist"></article-list>
         </view>
         <view class="swiper-item" :hidden="currenttab==0">
           <article-list :list="hecolllist"></article-list>
         </view>
      </view>
   </view>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        //用户xinx
        userInfo:[],
        toUserId:'',//被关注用户
        userId:'',//关注用户
        isCollection:1,
        currenttab:0,
        //用户收藏列表
        hecolllist:[],
        Fanstotal:0,
        Atttotal:0,
        //用户游记列表
        helist:[],
        hefanslist:[],
        queryObj:{
          pageNum:1,
          pageSize:5
        }
      };
    },
    onLoad(e) {
      // console.log(e);
      var toUserId=e.id
      this.toUserId=e.id
      this.userId=wx.getStorageSync('id')
      // this.userId=res.userId
      this.getHeColList(e.id)
      this.getHeList(e.id)
      this.getUser(e.id)
      this.getAttTotal(e.id)
      this.getFansTotal(e.id)
    },
    methods:{
      loadData(){
        this.onLoad()
      },
      swichNav(e){
        console.log(e.target.dataset.current);
          this.currenttab=e.target.dataset.current
      },
      goback(){
        uni.navigateBack({
          delta: 1
        })
      },
      gosend(id){
        uni.navigateTo({
          url:'/subpkg/message/message?id='+id
        })
      },
      // switchTab(e){
      //   this.currenttab=e.detail.current
      // },
      //获取我的收藏列表
      async getHeColList(id){
        const {data:res}=await uni.$http.get('/articles/myLikeArticles/'+id)
         if(res.code!=200) return uni.$showMsg("请求失败!")
         this.hecolllist=res.data
       },
       async getUser(id){
         const {data:res}=await uni.$http.get('/user/'+id)
         console.log(res);
         this.userInfo=res.data
         this.isCollection=res.data.isCollection
       },
       async getHeList(id){
         const {data:res}=await uni.$http.get('/articles/myArticles/'+id)
         if(res.code!=200) return uni.$showMsg("获取失败")
         console.log(res);
         this.helist=res.data
       },
       async getHeFansList(id){
         const {data:res}=await uni.$http.get('user/userFans/'+id,this.queryObj)
       },
       //关注用户
       async atuser(id){
        if(this.isCollection==0){
          this.isCollection=1
          const {data:res}=await uni.$http.post('/user/concernOtherUser',{
                toUserId:id,
                userId:this.userId,
                isCollection:1
          })
          if(res.code!=200) return uni.$showMsg('关注失败!')
          uni.$showMsg("关注成功！")
          console.log(res);
        }else{
          this.isCollection=0
          const {data:res}=await uni.$http.post('/user/concernOtherUser',{
                toUserId:id,
                userId:this.userId,
                isCollection:0
          })
          if(res.code!=200) return uni.$showMsg('关注失败!')
          uni.$showMsg("取消关注成功！")
          console.log(res);
        }
       },
       async getFansTotal(id){
          const {data:res}=await uni.$http.get('/user/userFans/'+ id )
          this.Fanstotal=res.data.length
        },
       async getAttTotal(id){
           const{data:res}=await uni.$http.get('/user//likeUsers/'+id)
           this.Atttotal=res.data.length
        },
      goUserHome(id){
        if(id==wx.getStorageSync('id')){
          uni.navigateTo({
            url:'/subpkg/user-home/user-home?id='+id
          })
        }else{
          uni.navigateTo({
            url:'/subpkg/user-home/user-home?id='+id
          })
        }
      },
       //跳转到粉丝列表
       goFansList(id){
         uni.navigateTo({
           url:'/subpkg/fanslist/fanslist?id='+id
         })
       }
    }
  }
</script>

<style lang="scss">
  .my-top{
    position: relative;
   .my-bg{
     border-radius: 10px;
     image{
       width: 100%;
     }
   }
   .my-avter{
     top: 150px;
     position: absolute;
     width: 100%;
     height: 90px;
     border-radius: 20px 20px 0 0;
     z-index: 1;
     background-color: #aaa;
     opacity: 0.8;
     .set{
       width: 30px;
       height: 30px;
       position: absolute;
       top: 12px;
       left: 12px;
     }
     .box-list{
       display: flex;
       position: absolute;
       right: 40px;
       top: -35px;
       align-items: center;
       text-align: center;
     }
     .box{
      display: flex;
       flex-direction: column;
       margin-left: 40rpx;
     }
     .tx{
       position: absolute;
       left: 70rpx;
       // transform:translateX(-50%);
       top: -45px;
       width: 70px;
       height: 70px;
       z-index: 9;
       border-radius: 50%;
     }
     .name{
       position: absolute;
       left: 60rpx;
       bottom: 40px;
       font-size: 38rpx;
       font-weight: 800;
     }
     .sex{
       position: absolute;
       left: 18rpx;
       bottom: 40px;
       width: 15px;
       height: 15px;
     }
     .address{
       position: absolute;
       left: 30rpx;
       bottom: 15px;
       padding: 5rpx 10rpx;
       .address-icon{
         width: 25rpx;
         height: 25rpx;
       }
       font-size: 28rpx;
       border: 1px solid #707e60;
       border-radius: 40rpx;
     }
     .fuction{
       z-index: 999;
       position: absolute;
       right: 30rpx;
       bottom: 15px;
       display: flex;
     }
     .message{
       padding: 10rpx 20rpx;
       background-color:#44cef6;
       color: aliceblue;
       font-size: 32rpx;
       border-radius: 20rpx;
       margin-right: 20px;
     }
     .guanzhu{
       padding: 10rpx 30rpx;
       background-color: #b02e28;
       color: #fff;
       font-size: 32rpx;
        border-radius: 20rpx;
     }
     .yiguanzhu{
       padding: 10rpx 20rpx;
       border-radius: 20rpx;
       background-color: #2E2E2E;
       color: #fff;
       font-size: 32rpx;
     }
   } 
   .arrow{
     width: 30px;
     height: 30px;
     position: absolute;
     // position: sticky;
     top: 30px;
     left: 15px;
     z-index: 999;
   }
  }
   .tab{
     background-color: #2E2E2E;
     border-radius: 10px;
     display: flex;
     align-items: center;
     text-align: center;
     justify-content: space-around;
     margin-top: -5px;
     padding: 10rpx 0;
     opacity: 0.9;
     .tab-item{
       width: 100rpx;
       height: 100%;
       padding: 20rpx 30rpx;
       font-size: 13px;
       color: #fff;
       border-radius: 40rpx;
       transition: all 1s;
     }
     .active{
       background-color: #fff;
       color: #2E2E2E;
     }
   }
   .tologin{
     .loginitem{
       height: 30px;
       width: 100px;
       margin-left: 50%;
       transform:translateX(-50%);
       // background-color: rgba(0, 0, 0, .2);
     }
   }
   swiper{
     height: 1600px;
   }
   .my-mid{
     // display: flex;
     position: absolute;
     width: 100%;
     top: 210px;
     // background-color: #cbe9c7;
     height: 130rpx;
     opacity: 0.8;
   }
</style>

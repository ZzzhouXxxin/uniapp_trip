//  先引入mockjs模块
import Mock from 'mockjs'

// 添加标签
Mock.mock('/mock/login', 'post', function (option) {
    console.log(option)

    return Mock.mock({
        status: 200,
        message: "注册成功",
        data:{
          number:''
        }
    })
})
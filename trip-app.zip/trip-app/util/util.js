 // //  获取状态栏信息
 //      fn() {
 //          let stateHeight = 0;		//  接收状态栏高度
 //          let navHeight = wx.getMenuButtonBoundingClientRect().height;
 //          let top = 0;
 //      	wx.getSystemInfo({
 //            success(res) {
 //              console.log("状态栏：" + res.statusBarHeight)
 //              stateHeight = res.statusBarHeight;
 //            }
 //          })
 //           this.navHeight=navHeight
 //            this.stateHeight=stateHeight		
 //      }